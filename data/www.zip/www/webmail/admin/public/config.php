<?php
$theme_wm_config = array(
    'login'	=> 'login',
    'style'	=> '',
);

$imap_config = array(
    'host' => '127.0.0.1',
    'port' => '143'
);

$smtp_config = array(
    'host' => '127.0.0.1',
    'port' => '25'
);

$sizequery_config = array(
    'host' => '127.0.0.1',
    'port' => 10029,
);

$private_api_config = array(
    'url'      => '/webmail/api.php',
    'key'      => 'bNF5QRW8IqXtNi2iSa9h75osAPYJEZ',
    'clientip' => array('127.0.0.1', '192.168.1.156', '192.168.33.1')
);

$default_language = 'zh_CN';

