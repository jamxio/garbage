////////////////////////////////////////////////////////////
//






////////////////////////////////////////////////////////////
// 旧版移植函数
////////////////////////////////////////////////////////////

/* 写邮件时地址簿用函数
 **********************************************************/

var comABToFields = "to";

var addrDiv ;
//查询数据组是否存在指定项目
function findArrayItem(array, item) {for(var i=0; i<array.length; i++) {if(array[i] == item) return true;}return false;}

var click_num = 0;
//右侧菜单切换
function comABSwitch(type) {
    var com_btn_1 = document.getElementById('ABButton1');
    var com_btn_2 = document.getElementById('ABButton2');
    var target = document.getElementById('ABDataArea');
        //target.innerHTML = '';
    
    if(type == 'addressbook') {
        com_btn_1.className = "addressbookhead upHead";
        com_btn_2.className = "mostcontacthead";
        if(click_num == 0){
            target.innerHTML = document.getElementById('ABDataArea').innerHTML;
        }else{
            target.innerHTML = addrDiv;
        }
    } else {
        if(click_num == 0){
            addrDiv = document.getElementById('ABDataArea').innerHTML;
        }
        /*
        com_btn_1.className = "addressbookhead";
        com_btn_2.className = "mostcontacthead upHead";
        var html = '<div id="ABGroupArea" class="composeSearch"></div>';
            html += '<div id="ABSearchArea" class="composeSearch">';
            html += '<input id="ABKeyword" type="text" value="查找..." onFocus="if(this.value==\'查找...\')this.value=\'\';" onblur="if(this.value==\'\')this.value=\'查找...\';" />';
            html += '<img src="/webmail/client/resource/images/adressaearch.gif" align="absmiddle" onclick="comABSearch();"/>';
            html += '</div>';
            html += '<div id="ABContactArea" class="personal ps"></div>';
        target.innerHTML = html;
        comABTypeSwitch('contact');
        */
        jQuery.get('/webmail/module/widget/index.php?module=view&action=tpl-list', function (data) {
            com_btn_1.className = "addressbookhead";
            com_btn_2.className = "mostcontacthead upHead";
            target.innerHTML = data;
            click_num++;
            jQuery('#ABTypeSwitchStatus').html('tpl');
            //changeContactArea(jQuery(window.parent).height());
        });
    }
}


//切换个人通讯录、企业通讯录、常用联系人
function comABTypeSwitch(type) {
    jQuery('#ABTypeSwitchStatus').html(type);
    var search = document.getElementById('ABSearchArea');
    var group = document.getElementById('ABGroupArea');
    var domain = document.getElementById('ABDomainArea');
	var target = document.getElementById('ABContactArea');
	target.innerHTML = '';
    if(type == 'oab') {
        group.style.display = '';
        search.style.display = '';
        domain.style.display ='none';
        comOABShowDepartment();
    } else if(type == 'oab-all') {
        group.style.display = '';
        search.style.display = '';
        domain.style.display ='none';
        comOABShowDepartment();
    }
    else if(type == 'pab') {
        group.style.display = '';
        search.style.display = '';
        domain.style.display ='none';
        comPABShowGroup();
        comPABGetContact({is_page:1});
    } else if(type == 'cab') {
        group.style.display = '';
        search.style.display = 'none';
        domain.style.display ='none';
        comCABShowGroup();
        //comCABGetContact();
    } else if(type == 'oabshare') {
        group.style.display = 'none';
        search.style.display = 'none';
        domain.style.display ='';
        comOABShareShowGroup();
        //comOABShareGetContact();
    } else if(type == 'contact') {
        group.style.display = 'none';
        search.style.display = 'none';
        comABContact();
    }else if(type == 'maillist') {
        group.style.display = 'none';
        showMaillist();
    }
    //changeContactArea(jQuery(window.parent).height());
}
//取得邮件列表
function showMaillist(){
    var target = document.getElementById('ABContactArea');
    var url = "/webmail/client/mail/index.php?module=api&action=get-maillist";
    jQuery.get(url, function(ret_data) {
        var domain_name = ret_data.domain_name;
        var json_data = ret_data.record_data;
        var ul = document.createElement('ul');
        for(var i=0; i<json_data.length; i++) {
            var email = json_data[i].listname + '@' + domain_name;
            var email_show = json_data[i].listname + '@' + domain_name;
            var li = document.createElement('li');
                li.title = email;
                li.className = "composeAdressStyle";
                li.onmouseout = function(){this.className='composeAdressStyle';}
                li.onmouseover = function(){this.className='composeAdressStyle01';}
                li.onclick = function(){comSelectContact(this.title);}
                li.innerHTML = email_show;
            ul.appendChild(li);
        }

        target.innerHTML = '';
        target.appendChild(ul);
    },'json');
}

//取得常用联系数据
function comABContact() {
    var target = document.getElementById('ABContactArea');
    var url = "/webmail/module/mail/index.php?module=operate&action=contact&type=json&contact=normal";
    jQuery.get(url, function(ret_data) {
        var ul = jQuery("<ul/>");
        ul.html("");
        ret_data = eval('(' + ret_data + ')');
        jQuery(ret_data).each(function(){
            if (this.toString()) {
                var li = jQuery('<li title=\''+this.toString()+'\' onmouseout="this.className=\'composeAdressStyle\'" onmouseover="this.className=\'composeAdressStyle01\'" class="composeAdressStyle" onclick="comSelectContact(this.title);"/>');
                li.html(this.toString());
                ul.append(li);
            }
        });
        target.innerHTML = '<div class="ps">' + ul.html()+ '</div>';
    });
}


//查询地址簿
function comABSearch() {
    var type = document.getElementById('ABTypeArea').getElementsByTagName('select')[0].value;
    var keyword = document.getElementById('ABKeyword').value;

    if(keyword == '查找...' || keyword == '') {
        keyword = '';
    }

    if(type == 'oab') {
        var dept_id = document.getElementById('ABGroupArea').getElementsByTagName('select')[0].value;
        if(dept_id==""){ dept_id = -1;}
        comOABGetContact({'dept_id':-1,'keyword': keyword,'limit':20});
    }else if(type == 'pab'){
        comPABGetContact({'keyword': keyword,'limit':20});
    }else if(type == 'cab'){
        comCABGetContact({'keyword': keyword});
    }else if(type == 'oabshare'){
        var domain_id = document.getElementById('ABDomainArea').getElementsByTagName('select')[0].value;
        comOABShareGetContact({'domain_id':domain_id,'keyword': keyword});
    }

}


//显示个人通讯录分组
function comPABShowGroup() {
    var target = document.getElementById('ABGroupArea');
    target.innerHTML="";
    var url = "/webmail/module/pab/index.php?module=operate&action=group-get&gettype=all_without_user";
    var prefix = jQuery('<select onChange="comPABGetContact({\'group_id\': this.value,\'is_page\':1});" id="pabselect"><option value="" selected>选择联系组</option></select>');
    jQuery.get(url, function(page_data) {
        var option = "";
        page_data = eval(page_data);
        page_data.push({"groupname":"未分组联系人","group_id":0});
        jQuery(page_data).each(function(){
            option += "<option value=\"" +this.group_id + "\">" +this.groupname+ "</option>";
        });
        prefix.html(option);
        jQuery(target).append(prefix);
    });
}


//根据指定参数取得个人地址簿中的联系人
function comPABGetContact(param) {
    var target = document.getElementById('ABContactArea');
    var url = "/webmail/module/pab/index.php?module=operate&action=contact-get";

    jQuery.get(url, param,function(ret_data) {
        var json_data = ret_data.record_data;
        var ul = document.createElement('ul');
        for(var i=0; i<json_data.length; i++) {
            var email = '"'+json_data[i].fullname + '" <' + json_data[i].email + '>';
            var email_show = json_data[i].fullname + '&lt;' + json_data[i].email + '&gt;';
            var li = document.createElement('li');
                li.title = email;
                li.className = "composeAdressStyle";
                li.onmouseout = function(){this.className='composeAdressStyle';}
                li.onmouseover = function(){this.className='composeAdressStyle01';}
                li.onclick = function(){comSelectContact(this.title);}
                li.innerHTML = email_show;
            ul.appendChild(li);
        }

        //分页
        if(ret_data.page_count>1){
            var page = parseInt(ret_data.page);
            var group_id = ret_data.group_id;
            var keyword = ret_data.keyword || '';
            if(page>=2){
                prevpage = parseInt(page-1);
                var prev_page_label = document.createElement('span');
                prev_page_label.innerHTML = "<span style='padding:4px;cursor: pointer;' onclick='comPABGetContact({\"group_id\":"+group_id+",\"page\":"+prevpage+",\"keyword\":\""+keyword+"\",\"limit\":15,\"is_page\":1});'>上一页</span>";
                ul.appendChild(prev_page_label);
            }
            for(var i= page; i<=parseInt(page)+4 && i<=ret_data.page_count; i++) {
                var page_item = document.createElement('span');
                page_item.innerHTML = "<span onmouseover='this.style.fontWeight=\"bold\";' onmouseout='this.style.fontWeight=\"normal\";' style='padding:2px;cursor: pointer;' onclick='comPABGetContact({\"group_id\":"+group_id+",\"page\":"+i+",\"keyword\":\""+keyword+"\",\"limit\":15,\"is_page\":1});'>"+i+"</span>";
                ul.appendChild(page_item);
            }
            if(page<parseInt(ret_data.page_count)){
                nextpage = parseInt(page+1);
                var next_page_label = document.createElement('span');
                next_page_label.innerHTML = "<span style='padding:4px;cursor: pointer;' onclick='comPABGetContact({\"group_id\":"+group_id+",\"page\":"+nextpage+",\"keyword\":\""+keyword+"\",\"limit\":15,\"is_page\":1});'>下一页</span>";
                ul.appendChild(next_page_label);
            }
        }

        target.innerHTML = '';
        target.appendChild(ul);
    },'json');
}


//显示企业通讯录部门
function comOABShowDepartment() {
    var target = document.getElementById('ABGroupArea');
    var url = "/webmail/module/oab/index.php?module=operate&action=dept-recurs-get";
    var prefix  = '<select onChange="comOABGetContact({\'dept_id\': this.value,\'limit\':15});">';
        prefix += '<option value="">请选择部门</option>';
    var suffix = '</select>';
    target.innerHTML="";
    jQuery.get(url, {}, function(page_data) {
        target.innerHTML = prefix + page_data + suffix;
		comOABGetContact({'dept_id': -1,'limit':15});
	});
}

/*function comOABShowDepartment(dept) {
	if(dept == undefined)
		dept = -1;
	if(dept != -1 && $('#dept_child_' + dept).length != 0){
		$('#dept_child_' + dept).remove();	
		$('#dept' + dept).children('img').prop('src', '/webmail/static/script/umail/AsyncTree/images/tree_plus.gif');
	}
	
	else
	jQuery.get('/webmail/module/oab/index.php?module=operate&action=dept-and-user-tree&dept=' + dept, function (data) {
		if(data){
			var json = eval('(' + data + ')');
			var temphtml = '';
			var addressids = $('#addressids').val().split(",");
			for(var d in json.dept){
				if(!json.dept.hasOwnProperty(d)) continue;
				var dept_data  = json.dept[d];
				temphtml += '<div id="dept' + dept_data["dept_id"] + '" class="treenewbee" _name="' + dept_data["name"] + '" _email="d_' + dept_data["dept_id"] + '@' + window.domain + '">';
				if(d + 1 == json.dept.length && !json.user && !dept_data["has_child"])
					temphtml += '<img src="/webmail/static/script/umail/AsyncTree/images/tree_joinbottom.gif">';
				else if(dept_data["has_child"])
					temphtml += '<img src="/webmail/static/script/umail/AsyncTree/images/tree_plus.gif" onclick="comOABShowDepartment(' + dept_data["dept_id"] + ')" style="cursor:pointer">';	
				else
					temphtml += '<img src="/webmail/static/script/umail/AsyncTree/images/tree_join.gif">';
				temphtml += ' <input type="checkbox" onclick="addEmail(\'dept' + dept_data["dept_id"] + '\')"';
				if(in_array('dept' + dept_data["dept_id"], addressids))
					temphtml += ' checked';
				temphtml += '/>	' + dept_data["name"];
				temphtml += ' </div>';
			}
			
			for(var u in json.user){
				if(!json.user.hasOwnProperty(u)) continue;
				var user_data  = json.user[u];
				temphtml += '<div id="user' + user_data["mailbox_id"] + '" class="treeoldbee" _name="' + user_data["name"] + '" _email="' + user_data["email"] + '">';
				if(u + 1 == json.user.length)
					temphtml += '<img src="/webmail/static/script/umail/AsyncTree/images/tree_joinbottom.gif">';
				else
					temphtml += '<img src="/webmail/static/script/umail/AsyncTree/images/tree_join.gif">';
				temphtml += ' <input type="checkbox" onclick="addEmail(\'user' + user_data["mailbox_id"] + '\')"';
				if(in_array('user' + user_data["mailbox_id"], addressids))
					temphtml += ' checked';
				temphtml += '/>	' + user_data["name"] + '&lt;' + user_data["email"] + '&gt;';
				temphtml += ' </div>';
			}
			
			if(dept == -1)
				$('#ABContactArea').html(temphtml);
			else{
				$('#dept' + dept).append('<div id="dept_child_' + dept +'" style="padding-left:22px">' + temphtml + ' </div>');
				$('#dept' + dept).children('img').prop('src', '/webmail/static/script/umail/AsyncTree/images/tree_minus.gif');
			}
		}
	});
}*/

function addEmail(id, type){
	if(type == undefined)
		type = 'checkbox';
	if(type == 'text'){
		var addressids = $('#addressids').val().split(",");
		if(in_array(id, addressids))
			var checked = true;
		else
			var checked = false;
	}
			
	var address = $('#' + id).attr('_name')	+ ' <' + $('#' + id).attr('_email') + '>; ';
	if(type == 'checkbox' && $('#' + id).children('input').prop('checked') == true || type == 'text' && checked == false){
		$('#' + comABToFields).val($('#' + comABToFields).val() + address);
		$('#addressids').val($('#addressids').val() + ($('#addressids').val()?',':'') + id);
	}
	else{
		$('#' + comABToFields).val($('#to').val().replace(address, ''));
		$('#addressids').val($('#addressids').val().replace(id, ''));
	}
}


//根据指定参数取得组织通讯录中的联系人
function comOABGetContact(param) {
    var target = document.getElementById('ABContactArea');
    var url = "/webmail/module/oab/index.php?module=operate&action=contact-list-get";

    //限制取得的用户数量
    if(param == undefined) {
        param = {};
    }
    jQuery.get(url, param, function(ret_data) {
        //alert(ret_data.dept_id);
        if(ret_data.dept_id==""){
            dept_id = -1;
        }else{
            dept_id = ret_data.dept_id;
        }
        var keyword = ret_data.keyword || '';
        var json_data = ret_data.record_data;
        var ul = document.createElement('ul');
        for(var i=0; i<json_data.length; i++) {
            var email = '"'+json_data[i].name + '" <' + json_data[i].email + '>';
            var email_show = json_data[i].name + '&lt;' + json_data[i].email + '&gt;';

            var li = document.createElement('li');
                li.title = email;
                li.className = "composeAdressStyle";
                li.onmouseout = function(){this.className='composeAdressStyle';}
                li.onmouseover = function(){this.className='composeAdressStyle01';}
                li.onclick = function(){comSelectContact(this.title);}
                li.innerHTML = email_show;
            ul.appendChild(li);
        }
        //分页
        if(ret_data.page_count>1){
            var page = parseInt(ret_data.page);
            if(page>=2){
                prevpage = parseInt(page-1);
                var prev_page_label = document.createElement('span');
                prev_page_label.innerHTML = "<span style='padding:4px;cursor: pointer;' onclick='comOABGetContact({\"dept_id\":"+dept_id+",\"page\":"+prevpage+",\"keyword\":\""+keyword+"\",\"limit\":15});'>上一页</span>";
                ul.appendChild(prev_page_label);
            }
            for(var i= page; i<=parseInt(page)+4 && i<=ret_data.page_count; i++) {
                var page_item = document.createElement('span');
                page_item.innerHTML = "<span onmouseover='this.style.fontWeight=\"bold\";' onmouseout='this.style.fontWeight=\"normal\";' style='padding:2px;cursor: pointer;' onclick='comOABGetContact({\"dept_id\":"+dept_id+",\"page\":"+i+",\"keyword\":\""+keyword+"\",\"limit\":15});'>"+i+"</span>";
                ul.appendChild(page_item);
            }
            if(page<parseInt(ret_data.page_count)){
                nextpage = parseInt(page+1);
                var next_page_label = document.createElement('span');
                next_page_label.innerHTML = "<span style='padding:4px;cursor: pointer;' onclick='comOABGetContact({\"dept_id\":"+dept_id+",\"page\":"+nextpage+",\"keyword\":\""+keyword+"\",\"limit\":15});'>下一页</span>";
                ul.appendChild(next_page_label);
            }
        }

        target.innerHTML = '';
        target.appendChild(ul);
    },'json');
}

function comCABShowGroup(){
    var target = document.getElementById('ABGroupArea');
    var url = "/webmail/module/cab/index.php?module=api&action=get-cab-select";
    var prefix  = '<select onChange="comCABGetContact({\'dept_id\': this.value});">';
        prefix += '<option value="">选择部门</option>';
    var suffix = '</select>';
    target.innerHTML="";
    jQuery.get(url, {}, function(page_data) {
        target.innerHTML = prefix + page_data + suffix;
		comCABGetContact({'dept_id': -1});
    });
}
function comCABGetContact(param){
    var target = document.getElementById('ABContactArea');
    var url = "/webmail/module/cab/index.php?module=api&action=contact-list&compose=1";

    //限制取得的用户数量
    if(param == undefined) {
        param = {};
    }
	
	jQuery.get(url, param, function(data) {
        var temphtml = '';
    	for(var i=0; i<data.length; i++) {
            var email_show = data[i].name + '&lt;' + data[i].email + '&gt;';

            temphtml += '<div id="cab' + data[i]["customer_id"] + '" _name="' + data[i].name + '" _email="' + data[i].email + '" style="cursor:pointer" onclick="addEmail(\'cab' + data[i]["customer_id"] + '\', \'text\')">';
			temphtml += email_show;
			temphtml += ' </div>';

        }
		target.innerHTML = temphtml;
    },'json');
}
function comOABShareShowGroup(){
    var target = document.getElementById('ABDomainArea');
    var url = "/webmail/module/oab/index.php?module=operate&action=get-sharedomain-select";
    var prefix  = '<select onChange="comOABShareGetDept();">';
    var suffix = '</select>';
    target.innerHTML="";
    jQuery.get(url, {}, function(page_data) {
        target.innerHTML = prefix + page_data + suffix;
		comOABShareGetDept();
    });
	
}
function comOABShareGetDept(dept){
    if(dept == undefined)
		dept = -1;
	
	var domain_id = $('#ABDomainArea').children('select').val();
	if(dept != -1 && $('#shared' + dept).children('img').prop('src').substr(-14) == 'tree_minus.gif'){
		$('#share_child_' + dept).remove();	
		$('#shared' + dept).children('img').prop('src', '/webmail/static/script/umail/AsyncTree/images/tree_plus.gif');
	}
	
	else
	jQuery.get('/webmail/module/oab/index.php?module=operate&action=dept-and-user-tree&domain_id=' + domain_id + '&dept=' + dept, function (data) {
		if(data){
			var json = eval('(' + data + ')');
			var temphtml = '';
			var addressids = $('#addressids').val().split(",");
			for(var d in json.dept){
				if(!json.dept.hasOwnProperty(d)) continue;
				var dept_data  = json.dept[d];
				temphtml += '<div id="shared' + dept_data["dept_id"] + '" class="treenewbee" _name="' + dept_data["name"] + '" _email="d_' + dept_data["dept_id"] + '@' + window.domain + '">';
				if(d + 1 == json.dept.length && !json.user && !dept_data["has_child"])
					temphtml += '<img src="/webmail/static/script/umail/AsyncTree/images/tree_joinbottom.gif">';
				else if(dept_data["has_child"])
					temphtml += '<img src="/webmail/static/script/umail/AsyncTree/images/tree_plus.gif" onclick="comOABShareGetDept(' + dept_data["dept_id"] + ')" style="cursor:pointer">';	
				else
					temphtml += '<img src="/webmail/static/script/umail/AsyncTree/images/tree_join.gif">';
				temphtml += ' <input type="checkbox" onclick="addEmail(\'shared' + dept_data["dept_id"] + '\')"';
				if(in_array('shared' + dept_data["dept_id"], addressids))
					temphtml += ' checked';
				temphtml += '/>	' + dept_data["name"];
				temphtml += ' </div>';
			}
			
			for(var u in json.user){
				if(!json.user.hasOwnProperty(u)) continue;
				var user_data  = json.user[u];
				temphtml += '<div id="shareu' + user_data["mailbox_id"] + '" class="treeoldbee" _name="' + user_data["name"] + '" _email="' + user_data["email"] + '">';
				if(u + 1 == json.user.length)
					temphtml += '<img src="/webmail/static/script/umail/AsyncTree/images/tree_joinbottom.gif">';
				else
					temphtml += '<img src="/webmail/static/script/umail/AsyncTree/images/tree_join.gif">';
				temphtml += ' <input type="checkbox" onclick="addEmail(\'shareu' + user_data["mailbox_id"] + '\')"';
				if(in_array('shareu' + user_data["mailbox_id"], addressids))
					temphtml += ' checked';
				temphtml += '/>	' + user_data["name"] + '&lt;' + user_data["email"] + '&gt;';
				temphtml += ' </div>';
			}
			
			if(dept == -1)
				$('#ABContactArea').html(temphtml);
			else{
				$('#shared' + dept).append('<div id="share_child_' + dept +'" style="padding-left:22px">' + temphtml + ' </div>');
				$('#shared' + dept).children('img').prop('src', '/webmail/static/script/umail/AsyncTree/images/tree_minus.gif');
			}
		}
	});
}
//设置要添加联系人的表单对象
function comSetABFields(fields) {
    comABToFields = fields;
}
//将选择的联系人加入至表单对象中
function comSelectContact(email) {
    if(!comABToFields) return;
    var target  = document.getElementById(comABToFields);

    email = email.replace("&lt;", '<');
    email = email.replace("&gt;", '>');

    if(target.value != '') {
        var arr_tmp = target.value.split(';');
        if(!findArrayItem(arr_tmp, email)) {
            target.value += email + ';';
        }
    } else {
        target.value = email + ';';
    }
	jQuery('#'+comABToFields).trigger("change");
}
