//���ؿؼ�
try {
  document.writeln("<OBJECT classid=\"clsid:2C9BABF1-EB08-4CCD-B53B-9DF52D5526A2\" id=eCert width=0 height=0 style=\"HEIGHT: 0px; LEFT: 0px; TOP: 0px; WIDTH: 0px\" VIEWASTEXT>");
  document.writeln("</OBJECT>");
  eCert.getKeyCount();
} catch(e) {
  //alert("��������ڻ���δע��");
}

//ǩ������
function Signature(message) {
  try {
    return eCert.Signature(message);
  } catch(e) {
    alert("Signature Failed");
  }
}

//ǩ������2
function Signature_2(message, issuerCN, ownerOU) {
  try {
    return eCert.Signature_2(message, issuerCN, ownerOU);
  } catch(e) {
    alert("Signature_2 Failed");
  }
}

//�ļ�ǩ��
function Signature_file(filePath, issuerCN, ownerOU) {
  try {
    return eCert.Signature_file(filePath, issuerCN, ownerOU);
  } catch(e) {
    alert("Signature_file Failed");
  }
}

//�ļ���ǩ
function Verify_file(signdata, filePath) {
  try {
    return eCert.Verify_file(signdata, filePath);
  } catch(e) {
    alert("Verify_file Failed");
  }
}

//�ļ�ǩ��2 md5
function Signature_file2(filePath, issuerCN, ownerOU) {
  try {
    return eCert.Signature_file2(filePath, issuerCN, ownerOU);
  } catch(e) {
    alert("Signature_file2 Failed");
  }
}

//�ļ���ǩ2 md5
function Verify_file2(signdata, filePath) {
  try {
    return eCert.Verify_file2(signdata, filePath);
  } catch(e) {
    alert("VerifyFile Failed");
  }
}


//��֤ǩ��
function Verify(signdata, message) {
  try {
    return eCert.Verify(signdata, message);
  } catch(e) {
    alert("Verify Failed");
  }
}

//��Կ����
function PublicKeyEncrypt(fileAddress, base64Cert) {
  try {
    return eCert.PublicKeyEncrypt(fileAddress, base64Cert);
  } catch(e) {
    alert("PublicKeyEncrypt Failed");
  }
}

//˽Կ����
function PrivateKeyDecrypt(cipMessage) {
  try {
    return eCert.PrivateKeyDecrypt(cipMessage);
  } catch(e) {
    alert("PrivateKeyDecrypt Failed");
  }
}

//˽Կ����2
function PrivateKeyDecrypt_2(cipMessage, issuerCN, ownerOU) {
  try {
    return eCert.PrivateKeyDecrypt_2(cipMessage, issuerCN, ownerOU);
  } catch(e) {
    alert("PrivateKeyDecrypt_2 Failed");
  }
}

//˽Կ����(��֤�����к�)
function PrivateKeyDecryptByCerSn(cipMessage, certSn, pin) {
  try {
    return eCert.PrivateKeyDecryptByCerSn(cipMessage, certSn, pin);
  } catch(e) {
    alert("PrivateKeyDecryptByCerSn Failed");
  }
}

//����3DES��Կ
function TriDesKey() {
  try {
    return eCert.TriDesKey();
  } catch(e) {
    alert("TriDesKey Failed");
  }
}

//3DES����
function TriDesEncrypt_Ex(key, message) {
  try {
    return eCert.TriDesEncrypt_Ex(key, message);
  } catch(e) {
    alert("TriDesEncrypt_Ex Failed");
  }
}

//3DES����
function TriDesDecrypt_Ex(key, cipMessage) {
  try {
    return eCert.TriDesDecrypt_Ex(key, cipMessage)
  } catch(e) {
    alert("TriDesDecrypt_Ex Failed");
  }
}

//3DES�����ļ�
function TriDesEncrypt(key, fileName) {
  try {
    return eCert.TriDesEncrypt(key, fileName);
  } catch(e) {
    alert("TriDesEncrypt Failed");
  }
}

//3DES���ܲ�д���ļ�
function TriDesDecrypt(key, cipMessage, fileName) {
  try {
    return eCert.TriDesDecrypt(key, cipMessage, fileName);
  } catch(e) {
    alert("TriDesDecrypt Failed");
  }
}

//����SCB2��Կ
function GetSCB2Key() {
  try {
    return eCert.GetSCB2Key();
  } catch(e) {
    alert("GetSCB2Key Failed");
  }
}

//SCB2����
function HTSCB2Enc(key, plaintext) {
  try {
    return eCert.HTSCB2Enc(key, plaintext);
  } catch(e) {
    alert("HTSCB2Enc Failed");
  }
}

//SCB2����
function HTSCB2Dec(key, cryptograph) {
  try {
    return eCert.HTSCB2Dec(key, cryptograph);
  } catch(e) {
    alert("HTSCB2Dec Failed");
  }
}

//SCB2�����ļ�
function HTSCB2EncFile(key, filePath) {
  try {
    return eCert.HTSCB2EncFile(key, filePath);
  } catch(e) {
    alert("HTSCB2EncFile Failed");
  }
}

//SCB2���ܲ�д���ļ�
function HTSCB2DecFile(key, cipMessage, filePath) {
  try {
    return eCert.HTSCB2DecFile(key, cipMessage, filePath);
  } catch(e) {
    alert("HTSCB2DecFile Failed");
  }
}

//��ȡ֤�����к�
function CertSerialNumber(storeType) {
  try {
    return eCert.CertSerialNumber(storeType);
  } catch(e) {
    alert("CertSerialNumber Failed");
  }
}

//��ȡ֤�����к�2
function CertSerialNumber_2(storeType, issuerCN, ownerOU) {
  try {
    return eCert.CertSerialNumber_2(storeType, issuerCN, ownerOU);
  } catch(e) {
    alert("CertSerialNumber_2 Failed");
  }
}

//��ȡ֤�����к�(����ͨ�汾)
function CertSerialNumber_xxt(storeType) {
  try {
    return eCert.CertSerialNumber_xxt(storeType);
  } catch(e) {
    alert("CertSerialNumber_xxt Failed");
  }
}

//��ȡ֤������
function CertProperty(storeType) {
  try {
    return eCert.CertProperty(storeType);
  } catch(e) {
    alert("CertProperty Failed");
  }
}

//��ȡ֤������2
function CertProperty_2(storeType, issuerCN, ownerOU) {
  try {
    return eCert.CertProperty_2(storeType, issuerCN, ownerOU);
  } catch(e) {
    alert("CertProperty_2 Failed");
  }
}

//��ȡ֤��Ĺ�Կ
function GetPublicKeyFromCert(type) {
  try {
    return eCert.GetPublicKeyFromCert(type);
  } catch(e) {
    alert("GetPublicKeyFromCert Failed");
  }
}

//��ȡ֤��Ĺ�Կ2
function GetPublicKeyFromCert_2(type, issuerCN, ownerOU) {
  try {
    return eCert.GetPublicKeyFromCert_2(type, issuerCN, ownerOU);
  } catch(e) {
    alert("GetPublicKeyFromCert_2 Failed");
  }
}

//��֤֤��
function VerifyCert(sBase64Cert, sTrustCert, sCRL) {
  try {
    return eCert.VerifyCert(sBase64Cert, sTrustCert, sCRL);
  } catch(e) {
    alert("VerifyCert Failed");
  }
}

//��ȡkey���������е��ļ��ַ���
function GetFile(name) {
  try {
    return eCert.getFile(name);
  } catch(e) {
    alert("getFile Failed");
  }
}

//д��key���������е��ļ��ַ���
function WriteFile(pin, name, con) {
  try {
    return eCert.writeFile(pin, name, con);
  } catch(e) {
    alert("writeFile Failed");
  }
}

//����usbkey��PIN��
function EnterPin(pin) {
  try {
    return eCert.EnterPin(pin);
  } catch(e) {
    alert("EnterPin Failed");
  }
}

//��ȡkey����
function GetKeyCount() {
  try {
    return eCert.GetKeyCount();
  } catch(e) {
    //alert("GetKeyCount Failed");
  }
}

//��֤�������л�ȡ��ߵ���
function getDN(subject,sbj) {
    var str = "";
    var sdn = subject.split(",");
		var ii;
        for (ii = 0; ii < sdn.length; ii++) {
            var stmp = (sdn[ii]).split("=");
            if (trim(stmp[0])==sbj) {
            	str = stmp[1];
                return str;
            }
        }
        return str;
   }

//ȥ���ҿո�	
function trim(str){    
  return str.replace(/(^\s*)|(\s*$)/g, '');    
}  

//ȡ֤����Ч�ڣ���ʼ���ڣ�
function startDate(cer){
 try {
 	  var sd  = cer.substring(cer.indexOf("<NotBefore>") + "<NotBefore>".length, cer.indexOf("</NotBefore>"));
    return sd;
  } catch(e) {
    alert("CertProperty_2 Failed");
  }	 
}

//ȡ֤����Ч�ڣ��������ڣ�
function endDate(cer){
	  try {
 	  var ed  = cer.substring(cer.indexOf("<NotAfter>") + "<NotAfter>".length, cer.indexOf("</NotAfter>"));
    return ed;
  } catch(e) {
    alert("CertProperty_2 Failed");
  }	 
}

//ȡ֤������
function getSbj(cer){
	  try {
 	  var sd  = cer.substring(cer.indexOf("<Subject>") + "<Subject>".length, cer.indexOf("</Subject>"));
    return sd;
  } catch(e) {
    alert("CertProperty_2 Failed");
  }	 
}

//ȡ��Կ���֤�����к�
function getSerialNumber(cer){
	  try {
 	  var sd  = cer.substring(cer.indexOf("<SerialNumber>") + "<SerialNumber>".length, cer.indexOf("</SerialNumber>"));
    return sd;
  } catch(e) {
    alert("CertProperty_2 Failed");
  }	 
}

//ȡ֤ǩ��ֵ�﹫�h
function qmgy(cer){
	  try {
 	  var sd  = cer.substring(cer.indexOf("<Certificate>") + "<Certificate>".length, cer.indexOf("</Certificate>"));
    return sd;
  } catch(e) {
    alert("CertProperty_2 Failed");
  }	 
}



//ȡ֤ǩ��ֵ
function qmz(cer){
	  try {
 	  var sd  = cer.substring(cer.indexOf("<Signature>") + "<Signature>".length, cer.indexOf("</Signature>"));
    return sd;
  } catch(e) {
    alert("CertProperty_2 Failed");
  }	 
}

//���ݹ�Կ����֤������
function zssx(cer,type){
     try {
 	  var sd  = eCert.CertParse (cer,type);
    return sd;
  } catch(e) {
    alert("CertParse Failed");
  }	 
}

//ʱ�䴦������
function CompareDate(d1,d2)
{
return ((new Date(d1.replace(/-/g,"\/"))) > (new Date(d2.replace(/-/g,"\/"))));
}

function DateDiff(sDate1,sDate2){
var aDate,oDate1,oDate2,iDays ;
aDate =sDate1.split('-');
oDate1 = new Date(aDate[1]+'-'+aDate[2]+'-'+aDate[0]) ;
//ת��Ϊ04-19-2007��ʽ
aDate = sDate2.split('-');
oDate2 = new Date(aDate[1]+'-'+ aDate[2] +'-'+aDate[0]);
iDays = parseInt(Math.abs(oDate1 -oDate2)/1000/60/60/24);//�����ĺ�����ת��Ϊ����
return iDays ;
}

//֤���Ƿ���ڣ����ڷ���false��û���ڷ���true��
function InThePeriod(endate,serverdate){
  if(!CompareDate(endate,serverdate)){
	    //alert('��ʾ��֤���ѹ��ڣ��뼰ʱ���£�')
	    return false;
	}else{
	  var xc = DateDiff(endate,serverdate);
		if(xc<11){
		alert('��ʾ��֤�黹�� '+xc+' ����ڣ���ע�⼰ʱ���£�');
	  }
	  return true;
   }
}


//key��� js����
function showTime(){
//����key����
var count;
//ȡkey����
count=GetKeyCount();
  if(count<1){
    alert("�����usbkey" );
		return false;
  }else{
    if(count>1){
     alert("�뱣ֻ֤����һ��usbkey���˳����usbkey�����" );
		return false;
  }else{
    return true;
    }
    
  }
  
}
  
