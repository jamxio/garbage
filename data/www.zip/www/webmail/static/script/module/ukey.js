window.keyCount=GetKeyCount();

jQuery(function() {
	ukeyLogout();
});

var ukeyLogout = function(){
			var keyCountNow=GetKeyCount();
			if(window.keyCount == 1 && keyCountNow == 0){
				$.post('/webmail/index.php?module=operate&action=ukeylogout', function(data) {
					if(data){
						window.location.href = '/webmail/index.php';	
					}
				});
			}
			else{
				setTimeout('ukeyLogout()', 1000);}
		}