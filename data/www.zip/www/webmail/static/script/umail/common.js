/*
	written by bravf @ 2010.08.06
	based on jQuery1.4
*/
//------------------------------------------------Common Method Start
Array.prototype._indexOf = function(n){
	if("indexOf" in this){
		return this["indexOf"](n);	
	}
	for(var i=0;i<this.length;i++){
		if(n===this[i]){
			return i;	
		}
	}
	return -1;
};
Array.prototype.uniqueItem = function(){
	var o = {},newArr = [];
	for(var i=0;i<this.length;i++){
		!o[this[i]] && (o[this[i]]=true,newArr.push(this[i]));
	}
	return newArr;
};
String.prototype._trim = function(){
	return this.replace(/(^\s+)(\s+$)/g, ""); 
};
Array.prototype.removeArr = function(set){return this.filter(
    function(e,i,a){return set.indexOf(e)<0}
)};
//----------ajax操作
var AjaxMsg = {};
AjaxMsg.login_out = function(){
	alert(_e('js-overtime_logout',[],"您长时间没做操作或有人在其他地方使用该帐号登录，请重新登录！"));
	window.location.href="/webmail/index.php?module=operate&action=logout";
};
AjaxMsg.post_fn = function(url,data,fn){
	jQuery.ajax({
		type:"post",
		url:url,
		data:data,
		cache:false,
		dataType:"json",
		success:function(msg){
			if(msg && msg.status && msg.status==-1)AjaxMsg.login_out();
			fn && fn(msg);	
		},
		error:function(){
			//alert("Error!");
		}
	});
};
AjaxMsg.get_fn = function(url,fn){
	jQuery.ajax({
		type:"get",
		url:url,
		cache:false,
		dataType:"json",
		success:function(msg){
			if(msg && msg.status && msg.status==-1)AjaxMsg.login_out();
			fn && fn(msg);
		},
		error:function(){
			//alert("Error!");
		}
	});
};
//----------数据验证
var validate = {};
validate.filter = {
	//{"str":"...","filter":"email","empty":false,"tip":"不可为空"}
	email : function(str,empty,tip){
		var patten = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
		if( (empty && str.length>0 || !empty) && !patten.test(str)){
			alert(tip||_e('js-email_fmt_error', [], "邮箱格式不对!"));
			return false;	
		}
		return true;
	},
	//{"str":"...","filter":"phone","empty":false,"tip":"不可为空"}
	phone : function(str,empty,tip){
		var patten = /^(?:13\d|15\d|18\d)-?\d{5}(\d{3}|\*{3})/;
		if( (empty && str.length>0 || !empty) && !patten.test(str)){
			alert(tip||_e('js-mobile_fmt_error', [], "手机号码格式不对!"));
			return false;	
		}
		return true;
	},
	//{"str":"...","filter":"tel","empty":false,"tip":"不可为空"}
	tel : function(str,empty,tip){
		//var patten = /^(\(\d{3,4}\)|\d{3,4}-|\s)?\d{7,8}/;
		var patten = /^[\d-+]+/;
		if( (empty && str.length>0 || !empty) && !patten.test(str)){
			alert(tip||_e('js-tel_fmt_error', [], "电话号码格式不对!"));
			return false;	
		}
		return true;
	},
	fax : function(str,empty,tip){
		//var patten = /^[+]{0,1}(d){1,3}[ ]?([-]?((d)|[ ]){1,12})+$/;
		var patten = /^[\d-+]+/;
		if( (empty && str.length>0 || !empty) && !patten.test(str)){
			alert(tip||_e('js-fax_fmt_error', [], "传真号码格式不对!"));
			return false;	
		}
		return true;
	},
	qq : function(str,empty,tip){
		var patten = /^[1-9][0-9]{4,}$/;
		if( (empty && str.length>0 || !empty) && !patten.test(str)){
			alert(tip||_e('js-qq_fmt_error', [], "qq号码格式不对!"));
			return false;	
		}
		return true;
	},
	zip : function(str,empty,tip){
		var patten = /^\d+$/;
		if( (empty && str.length>0 || !empty) && !patten.test(str)){
			alert(tip||_e('js-zip_fmt_error', [], "邮编格式不对!"));
			return false;	
		}
		return true;
	},
	url : function(str,empty,tip){
		var patten = /^[a-zA-z]+:\/\/[^\s]*$/;
		if( (empty && str.length>0 || !empty) && !patten.test(str)){
			alert(tip||_e('js-url_fmt_error', [], "url格式不对!"));
			return false;	
		}
		return true;
	},
	reg : function(str,empty,regs,tip){
		if(empty && str.length>0 || !empty){
			for(var i=0;i<regs.length;i++){
				if(regs[i].test(str)){
					return true;
				}
			}
			alert(tip||_e('js-fmt_error', [], "格式不对!"));
			return false;
		}
		return true;
	}
};
validate.check = function(__){
	//{"str":"","filters":[{"filter":"empty","args":false,"tip":"格式不对"}]}
	var str = __.str;
	var filters = __.filters;
	
	for(var i=0;i<filters.length;i++){
		var o = filters[i];
		var fn = validate.filter[o.filter];
		
		if(!fn(str,o.args,o.tip)){
			return false;	
		};
	}
	return true;
};
//----------checkbox操作
var Common = {};
Common.get_checked_fn = function(checkboxs){
	var values = [];
	checkboxs.each(function(){
		var self = jQuery(this);
		self.attr("checked") && values.push(self.attr("value"));
	});
	return values.join(",");
};
Common.set_checked_fn = function(checkboxs,values){
	checkboxs.each(function(){
		var self = jQuery(this);
		values._indexOf(self.attr("value"))>-1 ? self.attr("checked",true) : self.attr("checked",false);
	});
}; 
Common.clear_checked_fn = function(checkboxs){
	Common.set_checked_fn(checkboxs,[]);
};
Common.checked_all_fn = function(checkboxs,state,fn){
	checkboxs.each(function(){
		jQuery(this).attr("checked",state);
		fn(jQuery(this));
	});
};
//----------input操作
Common.get_inputs_fn = function(inputs){
	var values = {};
	inputs.each(function(){
		var self = jQuery(this);
		values[self.attr("id")] = self.val();
	});
	return values;
};
Common.set_inputs_fn = function(inputs,values){
	inputs.each(function(){
		var self = jQuery(this);
		self.val(values[self.attr("id")] || "");
	});
};
Common.clear_inputs_fn = function(inputs){
	Common.set_inputs_fn(inputs,{});
};
//----------日期select设置
Common.set_date_select_fn = function(yearUi,monthUi,dayUi,y,m,d){
	/*yearUi.val(y);
	monthUi.val(m).change();
	dayUi.val(d);*/
};
Common.fill_day_select_fn = function(ui,y,m){
	ui.html("");
	var maxDay = (new Date(y,m,0)).getDate();
	for(var i=1;i<=maxDay;i++){
		ui.append(jQuery("<option/>").val(i).html(i));	
	}
};
Common.bind_date_select_event_fn = function(yearUi,monthUi,dayUi){
	var fn = function(){
		Common.fill_day_select_fn(dayUi,yearUi.val(),monthUi.val());
	};
	yearUi.bind("change",fn);
	monthUi.bind("change",fn);
};
//----------页面刷新
Common.refresh_page_fn = function(){
	window.location.reload();
};
//----------下拉菜单
Common.dropDown_fn = function(head,body){
	var flag = 0;
	head.bind("click",function(){
		flag = 1;
		body.toggle();		
	});
	jQuery(document).bind("click",function(){
		head.attr("display")!="none" && flag==0 && body.hide();
		flag=0;
	});	
};
//----------简单拖动
Common.drag_fn =  function(drag_o,handle_o){
	var x,y,m_x,m_y;
	handle_o.bind("mousedown",function(e){
		var e = e || window.event;
		m_x = e.clientX,m_y = e.clientY,x = parseInt(drag_o.css("left")),y = parseInt(drag_o.css("top"));
		jQuery(document).bind("mousemove",move);
		jQuery(document).bind("mouseup",stopMove);
	});
	var move = function(e){
		var e = e || window.event;
		window.getSelection ? window.getSelection().removeAllRanges() : document.selection.empty();
		drag_o.css({"left":Math.max(0,x + e.clientX-m_x),"top":Math.max(0,y+e.clientY-m_y)});
	};
	var stopMove = function(e){
		var e = e||window.event;
		jQuery(document).unbind("mousemove",move);
		jQuery(document).unbind("mouseup",stopMove);
	};
};
//------------------------------------------------End
//------------------------------------------------Base Api Start
//----------Mails
var Api = {};

Api.star_mail_fn = function(folder,mail,fn){
	AjaxMsg.get_fn("/webmail/module/mail/index.php?module=operate&action=mail-setflag&mailbox=" + folder + "&msgno=" + mail + "&flag=3",fn);
};
Api.unstar_mail_fn = function(folder, mail, fn){
	AjaxMsg.get_fn("/webmail/module/mail/index.php?module=operate&action=mail-unsetflag&mailbox=" + folder + "&msgno=" + mail + "&flag=3",fn);
};

Api.move_mails_fn = function(curr_folder, new_folder, mails, fn){
	AjaxMsg.get_fn("/webmail/module/mail/index.php?module=operate&action=mail-move"+"&source="+curr_folder+"&msgno="+mails+"&target="+new_folder,fn);
};
Api.copy_mails_fn = function(curr_folder, new_folder, mails, fn){
	AjaxMsg.get_fn("/webmail/module/mail/index.php?module=operate&action=mail-copy"+"&mailbox="+curr_folder+"&msgno="+mails+"&to="+new_folder,fn);
};
Api.flag_mails_fn = function(folder, mails, flag, fn){
	AjaxMsg.get_fn("/webmail/module/mail/index.php?module=operate&action=mail-flag-set"+"&mailbox="+folder+"&msgno="+mails+"&flag="+flag,fn);
};
Api.flag_all_mails_fn = function(folder, flag, fn){
    AjaxMsg.get_fn("/webmail/module/mail/index.php?module=operate&action=mail-flag-setall"+"&mailbox="+folder+"&flag="+flag, fn);
};
Api.unflag_mails_fn = function(folder, mails, flag, fn){
	AjaxMsg.get_fn("/webmail/module/mail/index.php?module=operate&action=mail-flag-set"+"&mailbox="+folder+"&msgno="+mails+"&flag="+flag,fn);
};
Api.del_mails_fn = function(folder, mails, erase, fn){//erase:0为移到垃圾箱，1为彻底删除
	AjaxMsg.get_fn("/webmail/module/mail/index.php?module=operate&action=mail-delete"+"&mailbox="+folder+"&msgno="+mails+"&erase="+erase,fn);
};
//----------Folders
Api.rename_folder_fn = function(values, fn){
	AjaxMsg.post_fn("/webmail/module/mail/index.php?module=operate&action=folder-rename",values,fn);
};
Api.del_folder_fn = function(values, fn){
	AjaxMsg.post_fn("/webmail/module/mail/index.php?module=operate&action=folder-delete",values,fn);
};
Api.get_folders_fn = function(is_refresh,fn){
	if(is_refresh) AjaxMsg.get_fn("/webmail/index.php?module=operate&action=session-update",null);
	AjaxMsg.get_fn("/webmail/index.php?module=operate&action=session-get",fn);
};
Api.clear_folders_fn = function(folder,fn){
	AjaxMsg.post_fn("/webmail/module/mail/index.php?module=operate&action=folder-trash-clean",{"mailbox":folder},fn);
};
 Api.clear_normal_folders_fn = function(folder,fn){
	AjaxMsg.post_fn("/webmail/module/mail/index.php?module=operate&action=folder-clean",{"mailbox":folder},fn);
};
//----------Person Contacts
Api.get_group_contact_fn = function(fn){//获取联系组、联系人合并数据接口
	AjaxMsg.get_fn("/webmail/module/pab/index.php?module=operate&action=group-get&gettype=json",fn);
};
Api.get_contacts_fn = function(group_id,orderby,is_reverse,fn){//获取联系人列表接口
	AjaxMsg.get_fn("/webmail/module/pab/index.php?module=operate&action=contact-get"+"&group_id="+group_id+"&orderby="+orderby+"&is_reverse="+is_reverse,fn);};
Api.get_contact_info_fn = function(id,fn){//获取指定联系人接口
	AjaxMsg.get_fn("/webmail/module/pab/index.php?module=operate&action=contact-get-by-id"+"&id="+id,fn);
};
Api.get_groups_fn = function(fn){//获取所有联系组信息 (不包含成员)
	AjaxMsg.get_fn("/webmail/module/pab/index.php?module=operate&action=group-get&gettype=all_without_user",fn);
};
Api.get_group_info_fn = function(id,fn){//获取指定联系组信息 (包含其成员ID)
	AjaxMsg.get_fn("/webmail/module/pab/index.php?module=operate&action=group-get-by-id"+ "&group_id="+id,fn);
};
Api.del_contact_fn = function(ids,fn){//删除联系人
	AjaxMsg.post_fn("/webmail/module/pab/index.php?module=operate&action=contact-delete",{"contact_ids":ids},fn);
};
Api.del_group_fn = function(id,fn){//删除联系组
	AjaxMsg.get_fn("/webmail/module/pab/index.php?module=operate&action=group-delete"+"&group_id="+id,fn);
};
Api.add_contact_fn = function(values,fn){//添加联系人
	AjaxMsg.post_fn("/webmail/module/pab/index.php?module=operate&action=contact-add",values,fn);
};
Api.edit_contact_fn = function(id,values,fn){//修改联系人
	AjaxMsg.post_fn("/webmail/module/pab/index.php?module=operate&action=contact-edit"+"&id="+id,values,fn);
};
Api.add_group_fn = function(values,fn){//添加联系组
	AjaxMsg.post_fn("/webmail/module/pab/index.php?module=operate&action=group-add",values,fn);
};
Api.edit_group_fn = function(id,values,fn){//修改联系组
	AjaxMsg.post_fn("/webmail/module/pab/index.php?module=operate&action=group-edit"+"&group_id="+id,values,fn);
};
//----------Guest Contacts
Api.get_guest_contacts_cates_fn = function(fn){//获取分类列表接口
	AjaxMsg.get_fn("/webmail/module/cab/index.php?module=api&action=cate-tree",fn);
};
Api.get_guest_contacts_fn = function(cate_id,keyword,page,limit,orderby,is_reverse,fn){//获取分类下的客户接口
	AjaxMsg.get_fn("/webmail/module/cab/index.php?module=api&action=contact-list"+"&cate_id="+cate_id+"&keyword="+keyword+"&page="+page+"&limit="+limit+"&orderby="+orderby+"&is_reverse="+is_reverse,fn);
};
Api.get_guest_contact_info_fn = function(id,fn){//获得客户详细信息
	AjaxMsg.get_fn("/webmail/client/cab/index.php?module=view&action=contact-detail"+"&id="+id,fn);
};
//----------Company Contacts
Api.get_company_contacts_cates_fn = function(id,fn){//获取分类列表接口
	AjaxMsg.get_fn("/webmail/client/oab/index.php?module=operate&action=department-get"+"&pid="+id,fn);
};
Api.get_company_contacts_fn = function(dept_id,keyword,page,limit,orderby,is_reverse,fn){//获取分类下的客户接口
	AjaxMsg.get_fn("/webmail/client/oab/index.php?module=operate&action=member-get"+"&dept_id="+dept_id+"&keyword="+keyword+"&page="+page+"&limit="+limit+"&orderby="+orderby+"&is_reverse="+is_reverse,fn);
};
Api.get_company_contact_info_fn = function(id,fn){//获得客户详细信息
	AjaxMsg.get_fn("/webmail/client/oab/index.php?module=view&action=contact-detail"+"&id="+id,fn);
};
//----------网络文件夹
Api.netDisk_add_folder = function(pid,name,fn){
	AjaxMsg.post_fn("/webmail/module/netdisk/index.php?module=operate&action=folder-add",{"parent_id": pid, "name":name},fn);
};
//------------------------------------------------End