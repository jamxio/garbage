var u = u || {};
u.w = u.w || {};

u.w.popup = function(args){
	if(!(this instanceof u.w.popup)){
		return new u.w.popup(args);	
	}
	this.initAll(args||{});
};
u.w.popup.prototype = {
	initAll : function(args){
		this.initParams(args);
		this.initHtml();
		this.setPos();
		this.setEvents();
		this.setOthers();
	},
	initParams : function(args){
		this.params = {"title":"umail","body":"umail","wh":[400,300],"drag":true}; 
		jQuery.extend(this.params,args);
	},
	initHtml : function(){
		var p = this.params;
		this.wrapper = jQuery("<div/>").addClass("popup").css({"width":p.wh[0],"height":p.wh[1]}).appendTo(jQuery("body"));
			this.head = jQuery("<div/>").addClass("popup-head").appendTo(this.wrapper);
				this.title = jQuery("<h3/>").html(p.title).addClass("popup-head-title").appendTo(this.head);
				this.closeBtn = jQuery("<div/>").addClass("popup-head-close").appendTo(this.head);
			this.body = jQuery("<div/>").addClass("popup-body").appendTo(this.wrapper);
				("string" == typeof p.body) ? this.body.html(p.body) : this.body.append(p.body);
	},
	setPos : function(){
		var width = document.body.clientWidth,height = document.body.scrollTop;
		var x = (width-parseInt(this.params.wh[0]))/2;
		var y = height + 30;
		this.wrapper.css({"left":x,"top":y});	
	},
	setEvents : function(){
		var that = this;
		this.closeBtn.bind("click",function(){
			that.hide();									
		});
	},
	setOthers : function(){
		this.params.drag && Common.drag_fn(this.wrapper,this.head);
	},
	reInner : function(o){
		if(o){
			o.t && this.title.html(o.t);
			o.b && (("string" == typeof o.b) ? this.body.html(o.b) : this.body.append(o.b));
		}
		this.wrapper.show();
	},
	show : function(){
		this.wrapper.show();	
	},
	hide : function(){
		this.params.beforeClose && this.params.beforeClose();
		this.wrapper.hide();	
	}
};
