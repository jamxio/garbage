/*
* design by bravf
* date : 2010.7.25
*/
var UMAIL = UMAIL || {};
UMAIL.widget = UMAIL.widget || {};
UMAIL.widget.table = function(tbbox,plbox,id,titles,serverUrl,urlParams,createTr){
	this.tbbox = typeof tbbox == "string" ? jQuery("#"+tbbox) : tbbox;
	this.plbox = typeof plbox == "string" ? jQuery("#"+plbox) : plbox;
	this.id = id;
	this.titles = titles;
	this.serverUrl = serverUrl;//ajax url
	this.createTr = createTr;//根据数据生成tr的方法，返回一个jquery tr对象
	this.params = urlParams;//初始化的用来ajax的url参数
	this.tbodyUi = null;
	this.pageLinksUi = null;
	this.currOrderUi = null;//当前排序箭头的UI引用
	this.powerCheck = null;//全选和反选的checkbox UI应用
	this.checkBoxs=[];//所有数据行checkbox的数组引用
	
	this.loading = jQuery("<tr><td colspan='" + parseInt(this.titles.length+1) + "'>loading...</td></tr>");
	this.init();
};
UMAIL.widget.table.prototype = {
	init : function(){
		this.initParams();
		this.buildTb();
	},
	initParams : function(){
		var defaultParams = {pageCount:0,page:1,orderby:"",is_reverse:1};//1为降序，0为升序
		jQuery.extend(defaultParams,this.params);
		this.params = defaultParams;
	},
	buildTb : function(){
		var self = this;
		var table = jQuery("<table/>").addClass("tb_normal");
		table.attr("id",self.id);
		/*build thead*/
		var thead = jQuery("<thead/>");
		var tr = jQuery("<tr/>");
		jQuery(this.titles).each(function(){
			var th = jQuery("<th/>").html(this.title);
			if("css" in this){
				var css = this.css;
				for(var style in css){
					th.css(style,css[style]);	
				}
			}
			if("field" in this){
				th.attr("_order",this.field);
				var order = jQuery("<span/>").html("[↑]").css("cursor","pointer");
				if(this.field == self.params.orderby){
					self.currOrderUi = order;
					self.currOrderUi.css({"color":"red"});	//初始化最初的排序箭头
				}
				order.click(function(){//点击排序
					if(th.attr("_order") == self.params.orderby){	
						if(self.params.is_reverse==0){
							self.params.is_reverse = 1;
							jQuery(this).html("[↑]");
						}else{
							self.params.is_reverse = 0;
							jQuery(this).html("[↓]");
						}
					}else{
						self.params.orderby = th.attr("_order");
						self.params.is_reverse = 1;
						jQuery(this).html("[↑]");
						if(self.currOrderUi){
							self.currOrderUi.css({"color":"#000"});	
						}
						self.currOrderUi = jQuery(this);
						self.currOrderUi.css({"color":"red"});
					}
					self.loadData();
				});
				th.append(order);	
			}
			tr.append(th);						
		});
		self.powerCheck = jQuery("<input type='checkbox'/>");
		self.powerCheck.click(function(){
			var isChecked = jQuery(this).prop("checked");
			jQuery(self.checkBoxs).each(function(){
				jQuery(this).prop("checked",isChecked);
			});
			if (typeof datatable_checkI == 'function') datatable_checkI(tr);
		});
		tr.prepend(jQuery("<th/>").append(self.powerCheck).css("width","35px"));
		thead.append(tr);
		/* build tbody*/
		this.tbodyUi = jQuery("<tbody/>");
		/*build tfoot*/
		this.pageLinksUi = jQuery("<div/>");
		/*table append*/
		table.append(thead).append(this.tbodyUi);
		this.tbbox.append(table);
		this.plbox.append(this.pageLinksUi);
	},
	loadData : function(params){
		var self = this;
		self.tbodyUi.html("");
		self.tbodyUi.append(self.loading);//加载进度提示
		params && (!params.page) && (params.page = 1);
		if(params){
			jQuery.extend(self.params,params);
		}
		var paramStr="";
		for(var i in self.params){
			if(i!="pageCount"){
				paramStr+="&" +	i + "=" + self.params[i];
			}
		}
		jQuery.ajax({
			url:self.serverUrl+paramStr,
			type:"get",
			cache:false,
			dataType:"json",
			success:function(data){
				self.tbodyUi.html("");
				
				self.powerCheck.attr("checked",false);
				self.checkBoxs = [];
				
				self.setTbody(data.record_data);
				self.setPageLinks(data.page_count||1);

				if (typeof datatable_loadCache == 'function') datatable_loadCache();
			},
			error:function(){
				alert("error!");	
			}
		});
	},
	setTbody : function(datas){
		var self = this;
		if(datas.length==0){
			var td = jQuery("<td/>").attr("colspan",self.titles.length+1).html("没有相关的数据!");
			self.tbodyUi.append(jQuery("<tr/>").append(td));
		}else{
			jQuery(datas).each(function(){
				var tr = self.createTr(this);
				var checkbox = jQuery("<input type='checkbox'/>");
				checkbox.click(function () {
					if (typeof datatable_checkI == 'function') datatable_check(tr);
				});
				self.checkBoxs.push(checkbox);
				tr.prepend(jQuery("<td/>").append(checkbox));
				self.tbodyUi.append(tr);
			});
		}
	},
	setPageLinks : function(pageCount){
		var self = this;
		var createPLink = function(index,content){/*生成连接*/
			var plink = jQuery("<span/>").html(content).attr("_id",index).addClass("pLink");
			plink.click(function(){
				self.params.page = parseInt(jQuery(this).attr("_id"));
				self.loadData();
			});
			if(self.params.page==index){
				plink.addClass("currPl");	
			}
			return plink;
		};
		self.pageLinksUi.html("");
		self.pageLinksUi.append(jQuery("<span/>").html(pageCount+"/"+self.params.page).addClass("pCount"));
		
		var prePage,nextPage;

		if(self.params.page>1){
			prePage = createPLink(self.params.page-1,"<<");
		}else{
			prePage = jQuery("<span/>").html("<<").css("color","#999");
		}
		self.pageLinksUi.append(prePage);
		if(self.params.page!=pageCount){
			nextPage = createPLink(self.params.page+1,">>");
		}else{
			nextPage = 	jQuery("<span/>").html(">>").css("color","#999");
		}
		/*默认最多显示9页*/
		var pageStart=1,pageEnd=1,preShow=4,afterShow=4;
		if(pageCount<=(preShow+afterShow+1)){
			pageEnd = pageCount;
		}else{
			if(self.params.page<=(preShow+1)){
				pageEnd = preShow + afterShow +1;
			}
			else if(self.params.page>=(pageCount-afterShow)){
				pageEnd = pageCount;
				pageStart = pageCount-afterShow-preShow;
			}else{
				pageStart = self.params.page - preShow;
				pageEnd = self.params.page + afterShow;
			}
		}
		for(var i=pageStart;i<=pageEnd;i++){
			var plink = createPLink(i,i);
			this.pageLinksUi.append(plink);	
		}
		self.pageLinksUi.append(nextPage);	
	}
};