void function($){

var com = js.namespace("com");
com.Popup = js.Class.create();

com.Popup.prototype = {
	init : function(conf){
		var me = this;
		me.conf = {"title":"hello","body":$("<div/>").html("world"),"width":300,"height":200,"drag":true};
		$.extend(me.conf,conf);
		me.initPop();
		me.event();
	}
	,initPop : function(){
		var me = this;
		me.body = $("<div/>").addClass("popup").css({"width":me.conf["width"],"height":me.conf["height"]});
		me.head = $("<div/>").addClass("head").html(me.conf["title"]);
		
		me.main = $("<div/>").addClass("body").append(me.conf["body"]);
		me.center();
		
		me.close = $("<div/>").addClass("close");
		
		me.body.append(me.head,me.main,me.close);
		$(document.body).append(me.body);
		
		if(me.conf["drag"]==true){
			js.easyDrag(me.body,me.head);
		}
	}
	,center : function(){
		var me = this
			,wh = js.pageClientWH()
			,left = (wh.width - me.conf.width)/2
			,top = (document.documentElement.clientHeight - me.conf.height)/2;
		me.body.css({"left":left,"top":top});
	}
	,reset : function(conf){
		var me = this;
		$.extend(me.conf,conf);
		me.head.html(me.conf["title"]);
		me.main.html("").append(me.conf["body"]);
		me.show();
		
		return me;
	}
	,reWH : function(conf){
		var me = this;
		$.extend(me.conf,conf);
		me.body.css({"width":parseInt(me.conf["width"]),"height":parseInt(me.conf["height"])});
		return me;
	}
	,event : function(){
		var me = this;
		me.close.mouseover(function(){
			$(this).css("color","red");
		}).mouseout(function(){
			$(this).css("color","");
		}).click(function(){
			me.body.hide();
		});
	}
	,show : function(){
		var me = this;
		me.body.show();
		me.center();
	}
	,hide : function(){
		this.body.hide();
	}
};

}(jQuery);