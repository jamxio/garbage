var com = js.namespace("com");
com.DataTable = js.Class.create();

com.DataTable.id = 0;
com.DataTable.prototype = {
	coreId : 0
	,init : function(conf){
		var me = this;
		me.id = "DataTable_"+com.DataTable.id++;
		me.conf = {
			"boxIn":$(document.body)
			,"titles" : []
			,"requestUrl":""
			,"trFn" : function(){}
			,"requestData" : {}
		};
		$.extend(me.conf,conf);
		me.request = new js.Request(me.conf.requestUrl,"get");
		me.emptyTip = $("<tr><td class='emptyTip' colspan='" + (me.conf["titles"].length+1) +"'>没有任何数据!</td></tr>")
		me.keyCheck = null;
		me.checks = [];
		me.initTable();
		//缓存被选中的行
		me.cacheChecked = [];
	}

	// 添加一个记录到cacheChecked
	,_cc_add : function(id){
		// this.cacheChecked.push(id);

		// 重新构造函数，检查是否存在 -- @lbh0131205
		var exist = false;
		for(var i=0,len=this.cacheChecked.length;i<len;i++){
			if(id==this.cacheChecked[i]){
				exist = true;
				break;
			}
		}
		if(!exist) {
			this.cacheChecked.push(id);
		}
	}
	// 删除一个记录到cacheChecked
	,_cc_del : function(id){
		for(var i=0,len=this.cacheChecked.length;i<len;i++){
			if(id==this.cacheChecked[i]){
				this.cacheChecked.splice(i,1);
				break;
			}
		}
	}
	// 根据缓存更新行选中状态
	,_set_tr_checked : function(tr,checkbox){
		var s = ","+this.cacheChecked.join(",")+",";
		if(s.indexOf(','+tr.attr("data-id")+',')!=-1){
			checkbox.attr("checked",true);
		}
	}
	,initTable : function(){
		var me = this;
		me.body = $("<table/>").addClass("dataTable");
		me.thead = $("<thead/>"),tr = $("<tr/>") , me.keyCheck = $('<input type="checkbox"/>');
		
		var th = $("<th/>").addClass("checkBox").addClass(me.id+"_th_0").append(me.keyCheck);
		tr.append(th);
		$(me.conf.titles).each(function(i){
			th = $("<th/>").addClass(me.id+"_th_"+(i+1)).html(this.toString());
			tr.append(th);
		});
		me.thead.append(tr);
		me.tbody = $("<tbody/>");
		me.body.append(me.thead,me.tbody);
		me.pageLinks = $("<div/>").addClass("pageLinks");
		
		me.conf["boxIn"].append(me.body,me.pageLinks);
		me.keyCheckChange();
	}
	,keyCheckChange : function(){
		var me = this;
		me.keyCheck.change(function(){
			var checked = this.checked,t,id;
			$(me.checks).each(function(){
				t = $(this);
				t.attr("checked",checked);
				// 更新选中缓存
				id = t.parent().parent().attr("data-id");
				if(checked){
					me._cc_add(id);
				} else{
					me._cc_del(id);
				}
			});
			if (typeof datatable_check == 'function') datatable_checkI(tr);
		});
	}
	,load : function(conf){
		var me = this;
		if(conf!=null){
			$.extend(me.conf["requestData"],conf);
		}
		me.request.data(me.conf["requestData"]).exec(function(data){
			//清空checks
			me.checks = [];
			//复原keyCheck
			me.keyCheck.attr("checked",false);
			me.conf["page"] = ~~data.page || 1;
			me.fillTbody(data.record_data);
			me.createLinks(data.page_count);
		});
	}
	,fillTbody : function(datas){
		var me = this;
		me.tbody.html("");
		if (datas.length==0){
			me.tbody.append(me.emptyTip)
			return;
		}
		$(datas).each(function(){
			var tr = me.conf.trFn(this) ,check = $('<input type="checkbox"/>');
			me.checks.push(check);
			tr.prepend($("<td/>").addClass("checkBox").append(check));
			me.tbody.append(tr);

			me._set_tr_checked(tr,check);

			// 绑定check change事件
			check.bind("click",function(){
				var t = $(this),id = tr.attr("data-id");
				// attr 返回 checked或者undefined
				// prop 返回true或false
				// attr->prop -- @lbh20131205
				if(t.prop("checked")==true){
					me._cc_add(id);
				}else{
					me._cc_del(id);
				}
				if (typeof datatable_check == 'function') datatable_check(tr);
			});
		});
	}
	,createLinks : function(pageCount){
		var me = this;
		me.pageLinks.html("");
		
		//页码信息
		var pageInfo = $("<span class='pageInfo'/>").html("共 <b>"+pageCount+"</b> 页 当前为第 <b>"+me.conf.page+"</b> 页");
		me.pageLinks.append(pageInfo);
		
		var prev = $("<span/>").html("上一页")
			,next = $("<span/>").html("下一页");
		
		prev.click(function(){
			me.load({"page":me.conf.page-1});
		});
		next.click(function(){
			me.load({"page":me.conf.page+1});
		});
		if(me.conf.page>1){
			me.pageLinks.append(prev);
		}
		if(me.conf.page<pageCount){
			me.pageLinks.append(next);
		}
	}
	,getChecked : function(){
		//得到所有被选中的checkbox元素
		var me = this ,rs=[];
		$(me.checks).each(function(){
			if(this.attr("checked"))rs.push(this);
		});
		return rs;
	}
};
