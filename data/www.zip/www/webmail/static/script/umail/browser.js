/**
 * 客户端浏览器种类版本判断，兼容国内双核浏览器判断
 */
var browser = {};

browser.ua = function () {
	return (typeof browser_userAgent == 'undefined') ? navigator.userAgent.toLowerCase() : browser_userAgent;
};

/**
 * 判断360安全浏览器（只适合于较低版本)
 */
browser.is360SEBrowser = function () {
	return !!(browser.ua().indexOf('360se') > -1);
};

/**
 * 判断搜狗高速浏览器
 */
browser.isSogou = function () {
	return !!(browser.ua().indexOf('metasr') > -1);
};

/**
 * 判断遨游浏览器
 */
browser.isMaxthon = function () {
	return !!(browser.ua().indexOf('maxthon') > -1);
};

/**
 * 判断QQ浏览器
 */
browser.isQQBrowser = function () {
	return !!(browser.ua().indexOf('qqbrowser') > -1);
};

/**
 * 判断猎豹浏览器
 */
browser.isLiebao = function () {
	return !!(browser.ua().indexOf('lbbrowser') > -1);
};

/**
 * 判断世界之窗浏览器
 */
browser.isTheworld = function () {
	return !!(browser.ua().indexOf('theworld') > -1);
};

/**
 * 判断淘宝浏览器
 */
browser.isTaoBrowser = function () {
	return !!(browser.ua().indexOf('taobrowser') > -1);
};

/**
 * 判断枫树浏览器
 */
browser.isCoolNovo = function () {
	return !!(browser.ua().indexOf('coolnovo') > -1);
};

/**
 * 判断百度浏览器
 */
browser.isBIDUBrowser = function () {
	return !!(browser.ua().indexOf('bidubrowser') > -1);
};

/**
 * 判断双核浏览器
 */
browser.isDualcore = function () {
	return browser.is360SEBrowser() || browser.isSogou() || browser.isMaxthon() || browser.isQQBrowser() || browser.isLiebao()
		|| browser.isTheworld() || browser.isTaoBrowser() || browser.isCoolNovo() || browser.isBIDUBrowser();
};

/**
 * 判断双核浏览器兼容模式
 */
browser.isCompatible = function () {
	return browser.isIE() && browser.isDualcore();
};

/**
 * 判断IE或IE内核的浏览器
 */
browser.isIE = function () {
	return !!(browser.ua().indexOf('msie') > -1);
};

/**
 * 判断IE10或IE10内核的浏览器
 */
browser.isIE10 = function () {
	return !!(browser.ua().indexOf('msie 10.0') > -1);
};

/**
 * 判断IE9或IE9内核的浏览器
 */
browser.isIE9 = function () {
	return !!(browser.ua().indexOf('msie 9.0') > -1);
};

/**
 * 判断IE8或IE8内核的浏览器
 */
browser.isIE8 = function () {
	return !!(browser.ua().indexOf('msie 8.0') > -1);
};

/**
 * 判断IE7或IE7内核的浏览器
 */
browser.isIE7 = function () {
	return !!(browser.ua().indexOf('msie 7.0') > -1);
};

/**
 * 判断IE6或IE6内核的浏览器
 */
browser.isIE6 = function () {
	return !!(browser.ua().indexOf('msie 6.0') > -1);
};


/**
 * 判断MS-IE浏览器
 */
browser.isMSIE = function () {
	return browser.isIE() && !browser.isDualcore();
};

/**
 * 判断MS-IE10浏览器
 */
browser.isMSIE10 = function () {
	return browser.isIE10() && !browser.isDualcore();
};

/**
 * 判断MS-IE9浏览器
 */
browser.isMSIE9 = function () {
	return browser.isIE9() && !browser.isDualcore();
};

/**
 * 判断MS-IE8浏览器
 */
browser.isMSIE8 = function () {
	return browser.isIE8() && !browser.isDualcore();
};

/**
 * 判断MS-IE7浏览器
 */
browser.isMSIE7 = function () {
	return browser.isIE7() && !browser.isDualcore();
};
/**
 * 判断MS-IE6浏览器
 */
browser.isMSIE6 = function () {
	return browser.isIE6() && !browser.isDualcore();
};

/**
 * 判断Webkit内核浏览器
 */
browser.isWebkit = function () {
	return !!(browser.ua().indexOf('applewebkit') > -1);
};

/**
 * 判断Gecko内核浏览器
 */
browser.isGecko = function () {
	return !!(browser.ua().indexOf('gecko') > -1);
};

/**
 * 判断Trident内核浏览器（适合于IE8及其更高版本）
 */
browser.isTrident = function () {
	return !!(browser.ua().indexOf('trident') > -1);
};

/**
 * 判断Chromium内核浏览器
 */
browser.isChromium = function () {
	return !!(browser.ua().indexOf('chrome') > -1);
};

/**
 * 判断Chromium内核浏览器
 */
browser.isPresto = function () {
	return !!(browser.ua().indexOf('presto') > -1);
};

/**
 * 判断火狐浏览器
 */
browser.isFirfox = function () {
	return !!(browser.ua().indexOf('firefox') > -1);
};

/**
 * 判断谷歌浏览器
 */
browser.isChrome = function () {
	return browser.isChromium() && !browser.isDualcore();
};

/**
 * 判断苹果浏览器
 */
browser.isSafari = function () {
	return !browser.isChromium() && (browser.ua().indexOf('safari') > -1);
};

/**
 * 判断欧朋浏览器
 */
browser.isOpera = function () {
	return !!(browser.ua().indexOf('opera') > -1);
};