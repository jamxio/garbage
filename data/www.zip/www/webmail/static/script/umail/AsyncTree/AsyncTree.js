var com = js.namespace("com");
com.AsyncTree = js.Class.create();

//初始化图片路径
void function(){
	var _ = com.AsyncTree
	,images = {
		folder : "tree_folder.gif",
		join : "tree_join.gif",
		line : "tree_line.gif",
		minus : "tree_minus.gif",
		minus_1 : "tree_minus_1.gif",
		plus : "tree_plus.gif",
		plus_1 : "tree_plus_1.gif",
		joinbottom : "tree_joinbottom.gif",
		empty: 'empty.png'
	};
	_.imgFolder = ROOT + "static/script/umail/AsyncTree/images/";
	_.images = {};
	for(var img in images){
		_.images[img] = _.imgFolder + images[img];
	}
}();

//对象方法
com.AsyncTree.prototype = {
	init : function(conf){
		var me = this;
		me.images = com.AsyncTree.images;
		me.conf = {"boxIn":$(document.body),"rootName":"Tree","initData":{},"idFiled":"id","requestUrl":"","nodeFn":function(){}};
		$.extend(me.conf,conf);
		me.request = new js.Request(me.conf.requestUrl ,"get");
		
		me.initTree();
	}
	,initTree : function(){
		var me = this;
		me.body = $("<div/>").addClass("asyncTree");
		me.createRoot();
		me.buildNodes(me.body,0,me.conf["initData"], '1');
		me.conf["boxIn"].append(me.body);
	}
	,createRoot : function(){
		var me = this
		,root = $("<div/>")
		,folder = $("<img/>").attr("src",me.images["folder"])
		,text = $("<span/>").html(me.conf.rootName).bind("click",function(){
			if(me.conf.nodeFn!=null){
				me.conf.nodeFn.call(me,-1,me.conf.rootName);
			}
		});
		
		root.append(folder,text);
		me.body.append(root);
	}
	,buildNodes : function(boxIn,deep,data,line,count){
		var me = this;
		var nodesCount =  data.length-1;
		
		$(data).each(function(i){
			var that = this;
			var node = $("<div/>");
			node.attr("_id",that[me.conf.idField]);
			node.attr("_deep",deep);
			node.attr('_end', '0');
			node.attr('_count', '0');
			if (count==null) count = -1;
			if (line=='1') {
				node.attr('_count', parseInt(count)+1);
				if (i == nodesCount) node.attr('_end', '1');
			}
			////纵线

			for(var j=0;j<deep;j++){
				if (line=='1') {
					empty = $('<img />');
					empty.attr('width', 18);
					empty.attr('height', 18);
					empty.attr('src', me.images["empty"]);
					node.append(empty);
				} else {
					if (j < count) {
						node.append('<img width="18" src="'+me.images["empty"]+'" />');
					} else {
						node.append($("<img/>").attr("src",me.images["line"]));
					}
				}
			}
			////横线
			var img = $("<img/>"),src=me.images["join"];
			//如果有子节点
			if(that.has_child){
				src = '';
				if (line=='1') {
					src = me.images["plus_1"];
				} else {
					src = me.images['plus'];
				}
				img.attr("_hasGet",0).addClass("expand");
				me.expandEvent(img);
			}else{
				//如果是本节点列最有一个节点
				if(i == nodesCount)src = me.images["joinbottom"];
			}
			img.attr("src",src);
			node.append(img);
			////文件夹
			node.append($("<img/>").attr("src",me.images["folder"]));
			////文本
			var text = $("<span/>").html(that.name).click(function(){
				me.colorNode($(this));
				if(me.conf["nodeFn"]!=null)me.conf["nodeFn"].call(me,that[me.conf.idField],that.name);
			});
			node.append(text);
			boxIn.append(node);
		});
	}
	,expandEvent : function(expand){
		var me = this;
		expand.click(function(){
			var that = jQuery(this),parent = that.parent();
			
			if(that.attr("_hasGet")==0){
				me.request.data({"pid":parent.attr("_id")}).exec(function(data){
					var nodesBox = $("<div/>");
					me.buildNodes(nodesBox,parseInt(parent.attr("_deep"))+1,data, parent.attr('_end'), parent.attr('_count'));
					nodesBox.insertAfter(parent);
					if (parent.attr('_end')=='0') {
						that.attr({"_hasGet":1 ,"src":me.images["minus"]});
					} else {
						that.attr({"_hasGet":1 ,"src":me.images["minus_1"]});
					}
				});
			}else{
				var nodesBox = parent.next();
				var _ = [ ["hide",me.images["plus"]] ,["show" ,me.images["minus"]]];
				if (parent.attr('_end')=='1') _ = [ ["hide",me.images["plus_1"]] ,["show" ,me.images["minus_1"]]];
				var i=0;
				if(nodesBox.css("display")=="none")i=1;
				
				nodesBox[_[i][0]]();
				that.attr("src",_[i][1]);
			}
		});
	}
	,colorNode : function(node){
		var me = this, color = "red";
		if(me.currNode!=null){
			me.currNode.css("color","");
		}
		me.currNode = node.css("color",color);
	}
};