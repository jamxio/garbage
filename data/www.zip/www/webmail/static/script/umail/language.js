(function(){

	try {
        if (window.langdata) {
            return;

        }

        if (window.parent.langdata) {
            window.langdata = window.parent.langdata;
            return;

        }
    }
    catch (e){
		console.log(e);
	}

	var url = '/webmail/index.php?module=operate&action=get-lang-data';
    var langdata = null;
    jQuery.ajax({
        'url': url,
        'async': false,
        'success': function(data) {
            data = eval('(' + data + ')');
            langdata = data;
            window.langdata = data;
        }
    });

    return langdata;
})();

function _e(key, param, def) {
	if(!key) {
		return key;
	}

	var lang = window.langdata[key];
	
	if(!lang) {
		return def? def: key;
	}
	
	if(lang && lang.indexOf('%s') != -1) {
		if(param.length) {
			jQuery.each(param, function(){
				lang = lang.replace('%s', jQuery(this));
			});
		}
	}

	return lang;
}