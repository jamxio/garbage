/**
* design by bravf @ 2010.7.25
*/
var UMAIL = UMAIL || {};
UMAIL.widget = UMAIL.widget || {};

/*tab*/
UMAIL.widget.TabCssManager = {/* tab css 管理器*/
	menu : "tab",
	
	leftImgUi   : "tab-menu-left",
	contentUi   : "tab-menu-content",
	rightImgUi  : "tab-menu-right",

	/*焦点状态下*/
	leftImgUi2  : "tab-menu-left2",
	tabActive   : "tab-active",
	rightImgUi2 : "tab-menu-right2",

	/*iframe*/
	iframeUi    : "tab-contentBox",

	/*closeBtn*/
	closeBtnUi     : "tab-menu-closeBtn",
	closeBtnActive : "tab-closeBtn-active"
	
};
UMAIL.widget.Tab = function(id,title,url,isClose){
	this.id = id;
	title = title || "unkown";
	title.replace("<","&lt;").replace(">","&gt;");//转义标题
	this.title = title.length>10?title.substring(0,10)+"...":title;
	this.url =  url;
	this.isClose = isClose;
	/*组成tab按钮的各部分*/
	this.menuUi = null;
	this.leftImgUi = null;
	this.contentUi = null;
	this.rightImgUi = null;
	this.closeBtnUi = null;
	/*与tab按钮对应的iframe*/
	this.iframeUi = null;
	this.iframeName = "f"+id;
	
	this.alive = true;
	this.init();
};
UMAIL.widget.Tab.prototype = {
	init : function(){
		this.buildUi();
	},
	buildUi : function(){
		/*menuUi*/
		this.menuUi = jQuery("<div/>").addClass(UMAIL.widget.TabCssManager.menu);
		
		var contentUiBox = jQuery("<ul/>");
		this.leftImgUi = jQuery("<li/>").html("&nbsp;").addClass(UMAIL.widget.TabCssManager.leftImgUi);
		this.contentUi = jQuery("<li/>").html(this.title).addClass(UMAIL.widget.TabCssManager.contentUi);
		this.rightImgUi = jQuery("<li/>").html("&nbsp;").addClass(UMAIL.widget.TabCssManager.rightImgUi);
		contentUiBox.append(this.leftImgUi).append(this.contentUi).append(this.rightImgUi);
		
		if(this.isClose){
			this.closeBtnUi = jQuery("<li/>").html("&nbsp;").addClass(UMAIL.widget.TabCssManager.closeBtnUi);
			this.closeBtnUi.mouseover(function(){
				jQuery(this).addClass(UMAIL.widget.TabCssManager.closeBtnActive);					
			});
			this.closeBtnUi.mouseout(function(){
				jQuery(this).removeClass(UMAIL.widget.TabCssManager.closeBtnActive);											   
			});
			contentUiBox.append(this.closeBtnUi);
		}
		this.menuUi.append(contentUiBox);

		/*iframeUi*/
		this.url = window.encodeURI(this.url);
		this.iframeUi = jQuery("<iframe/>").attr("name",this.iframeName).attr("id",this.id).attr("src",this.url).addClass(UMAIL.widget.TabCssManager.iframeUi).attr("frameborder","0");
	},
	removeUi : function(){
		this.alive = false;
		this.menuUi.remove();
		this.iframeUi.remove();
	},
	changeUi : function(title,url){
		if(this.title!=title){
			this.title = title;
			this.contentUi.html(title);
		}
		if(this.url != url){
			this.url = url;
			this.iframeUi.attr("src", this.url);
		}
	},
	changeClass : function(isActive){
		var self = this,d = jQuery(document);
		var fn = isActive ? (self.iframeUi.hide(),d.removeClass) : (self.iframeUi.show(),d.addClass);
		fn.call(self.leftImgUi,UMAIL.widget.TabCssManager.leftImgUi2);
		fn.call(self.rightImgUi,UMAIL.widget.TabCssManager.rightImgUi2);
		fn.call(self.contentUi,UMAIL.widget.TabCssManager.tabActive);	
	}
};
/*tabFrame*/
UMAIL.widget.TabFrameCssManager = {
	controllerBox : "tab-controllerBox"
};
UMAIL.widget.TabFrame = function(containerId){
	this.container = containerId ? jQuery("#"+containerId) : jQuery("body").eq(0);
	this.controllerBox = null;
	this.contentBox = null;
	this.tabs = [];
	this.tabId=0;
	this.activeTab = null;
	this.FH = 0;				//做iframe高度自适应
	this.addCallback = null;	//添加标签后执行的架设函数 (add by: haijd)

	this.init();
};
UMAIL.widget.TabFrame.prototype = {
	init : function(){
		this.buildBox();
	},
	setAddCallback : function (cb) {
		this.addCallback = cb;
	},
	add : function(title,url,isClose){//addTab的快捷方式
		var result = this.addTab({title:title, url:url, isClose:isClose});
		if(this.addCallback) this.addCallback();
		return result;
	},
	buildBox : function(){
		this.controllerBox = jQuery("<div/>").addClass(UMAIL.widget.TabFrameCssManager.controllerBox);
		this.contentBox = jQuery('<div id="iframeWrapper" />');
		var clear = jQuery("<div/>").css({"clear":"both"});
		if(jQuery.browser.msie){
			//clear.css("height","29px");	
		}
		this.container.append(this.controllerBox).append(clear).append(this.contentBox);
	},
	addTab : function(args){
		var params = {title:"空白页",url:"about:blank",isClose:true};
		jQuery.extend(params,args);

		var self = this;
		var checkHas = self.hasTab(params.url);
		if(checkHas.has){
			self.setActiveTab(checkHas.tab);
			return false;	
		}
		var tab = new UMAIL.widget.Tab(self.tabId++,params.title,params.url,params.isClose);

		tab.contentUi.click(function(){
			if(tab.id!=self.activeTab.id){/*判断目标tab是否已经是活动按钮*/
				self.setActiveTab(tab);
			}
		});
		if(tab.closeBtnUi){
			tab.closeBtnUi.click(function(){
				self.removeTab(tab);					  
			});
		}
		self.tabs.push(tab);
		self.controllerBox.append(tab.menuUi);
		self.contentBox.append(tab.iframeUi);
		self.setActiveTab(tab);
		return tab;
	},
	removeTab : function(tab){
		var self = this;
		if(self.tabs.length==1){
			alert("只有一个选项卡时候无法关闭!");
			return false;
		}
		tab.removeUi();
		for(var i=0,len=self.tabs.length;i<len;i++){
			if(self.tabs[i].id == tab.id){
				self.tabs.splice(i,1);
				self.activeTab.id===tab.id && self.setActiveTab(self.tabs[len-2]);
				break;
			}
		}
		return true;
	},
	remove : function(url){
		var has = this.hasTab(url);
		if(has.has){
			this.removeTab(has.tab);	
		}else{
			return false;	
		}
		return true;
	},
	changeTab : function(tab,title,url,isActive){
		if (isActive == null) {
			isActive = true;
		}
		tab.changeUi(title,url);
		if (isActive) {
			this.setActiveTab(tab);
		}
	},
	setActiveTab : function(tab){
		if(this.activeTab){
			if(this.activeTab.id == tab.id){
				return false;	
			}
			this.activeTab.changeClass(true);
		}
		tab.changeClass(false);
		this.activeTab = tab;
		return true;
	},
	setActive : function(title){
		var tab;
		for(var i=0;i<this.tabs.length;i++){
			if(this.tabs[i].title==title){
				tab = this.tabs[i];
				break;
			}
		}
		if(tab instanceof UMAIL.widget.Tab){
			this.setActiveTab(tab);	
		}
	},
	hasTab : function(url){
		for(var i=0;i<this.tabs.length;i++){
			if(this.tabs[i].url==url){
				return {has:true,tab:this.tabs[i]};	
			}
		}
		return {has:false};
	},
	tabByTitle : function(title){
		for(var i=0;i<this.tabs.length;i++){
			if(this.tabs[i].title==title){
				return this.tabs[i];
			}
		}
		return null;
	}
};