/*
* design by bravf
* date : 2010.7.25
*/
var UMAIL = UMAIL || {};
UMAIL.widget = UMAIL.widget ||  {};

UMAIL.widget.treeImgs = {
	_floder : "images/tree_folder.gif",
	_join : "images/tree_join.gif",
	_line : "images/tree_line.gif",
	_minus : "images/tree_minus.gif",
	_plus : "images/tree_plus.gif",
	_joinbottom : "images/tree_joinbottom.gif"
};
UMAIL.widget.tree = function(box, rootName, data, id_field, serverUrl, imgPath, w, h, nodeCall){
	this.box = typeof box =="string" ? jQuery("#"+box) : box;
	this.rootName = rootName;
	this.data = data;
	this.id_field = id_field;
	this.imgPath = imgPath;
	this.nodeCall = nodeCall;
	this.treeUi = null;
	this.serverUrl = serverUrl;
	this.w = w || 120;
	this.h = h || 350;
	this.init();
};
UMAIL.widget.tree.prototype = {
	init : function(){
		this.initTree();
	},
	initTree : function(){
		this.treeUi = jQuery("<div class='treeBody'/>").css({"width":this.w,"height":this.h});
		this.buildRoot();
		this.buildNodes(this.treeUi, 0, this.data);
		this.box.append(this.treeUi).addClass("tree");
	},
	buildRoot : function(){
		var self = this;
		var root = jQuery("<h4/>");
		root.append(jQuery("<img/>").attr("src",self.imgPath+UMAIL.widget.treeImgs._floder));
		root.append(jQuery("<span/>").html(self.rootName).click(
									function(){
										self.setCurrCss(root);
										!!self.nodeCall && self.nodeCall.call(this,-1,self.rootName);
									}
								));
		self.treeUi.append(root);
		
		self.setCurrCss(root);
	},
	buildNodes : function(box,deep,data){
		var self = this;
		var nodesCount =  data.length-1;
		jQuery(data).each(function(i){
			var that = this;
			var node = jQuery("<h4/>");
			node.attr("_id", that[self.id_field]);
			node.attr("_deep",deep);
			for(var j=0;j<deep;j++){
				node.append(jQuery("<img/>").attr("src",self.imgPath+UMAIL.widget.treeImgs._line));	
			}
			var img = jQuery("<img/>"),imgUrl = UMAIL.widget.treeImgs._join;

			if(that.has_child){
				imgUrl = UMAIL.widget.treeImgs._plus;	
				img.addClass("expand");
				img.attr("_hasGet",0);
				self.bindEvent(img);
			}else{
				if(nodesCount == i){
					imgUrl = UMAIL.widget.treeImgs._joinbottom;	
				}
			}
			img.attr("src",self.imgPath + imgUrl);
			node.append(img);
			node.append(jQuery("<img/>").attr("src",self.imgPath+UMAIL.widget.treeImgs._floder));
			node.append(jQuery("<span/>").attr('title', that.name).html(that.name).click(
										  function(){
											  self.setCurrCss(node);
											  !!self.nodeCall && self.nodeCall.call(this,node.attr("_id"),that.name);
									   		})
			);
			box.append(node);
		});
	},
	setCurrCss : function(node){
		this.currNode && this.currNode.css("color","#000");
		this.currNode = node.css("color","red");
	},
	bindEvent : function(expand){
		var self = this;

		expand.click(function(){
			var that = jQuery(this),node = that.parent();
			if(that.attr("_hasGet")==0){
				jQuery.ajax({
					url:self.serverUrl+"&pid="+node.attr("_id"),
					type:"get",
					cache:false,
					dataType:"json",
					success:function(data){
						var nodesBox = jQuery("<div/>");
						self.buildNodes(nodesBox,parseInt(node.attr("_deep"))+1,data);
						nodesBox.insertAfter(node);
						that.attr("_hasGet",1);
						that.attr("src",self.imgPath+UMAIL.widget.treeImgs._minus);
					},
					error:function(){
						alert("数据加载失败!");	
					}
				});
			}else{
				var nodesBox = node.next();
				if(nodesBox.css("display")!="none"){
					nodesBox.hide();
					that.attr("src",self.imgPath+UMAIL.widget.treeImgs._plus);
				}else{
					nodesBox.show();
					that.attr("src",self.imgPath+UMAIL.widget.treeImgs._minus);
				}
			}				  
		});
	}
};