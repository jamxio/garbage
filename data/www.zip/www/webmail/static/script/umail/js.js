void function($){

var js = {};
window["js"] = js;


//命名空间
js.namespace = function(name){
	var names = name.split(".");
	var space = window;
	for(var i=0,len=names.length;i<len;i++){
		name = names[i];
		if(space[name]==null){
			space[name]={};
		}
		space = space[name];
	}
	return space;
};

//类
js.Class = {
	create : function(){
		return function(){
			this.init.apply(this,arguments);
		}
	}
};

//一个jquery request对象
js.Request = js.Class.create();
js.Request.prototype = {
	init : function(url,type){
		this.url = url;
		this.type = type;
	},
	dataType : function(dataType){
		this._dataType = dataType;
		return this;
	},
	data : function(o){
		this.params = o;
		return this;
	},
	next : function(fn){
		var me = this;
		if(!me.nexts)me.nexts = [];
		me.nexts.push(fn);
		return me;
	},
	nextErr : function(fn){
		var me = this;
		if(!me.nextErrs)me.nextErrs = [];
		me.nextErrs.push(fn);
		return me;
	},
	exec : function(fn){
		var me = this;
		$.ajax({
			url : me.url,
			type : me.type,
			data : me.params || {},
			dataType : me._dataType || "json",
			success : function(data){
				if(fn!=null){
					fn.call(null,data);
					return;
				}
				if(!me.nexts)return;
				for(var i=0;i<me.nexts.length;i++){
					me.nexts[i].call(null,data);
				}
			},
			error : function(){
				if(!me.nextErrs)return;
				for(var i=0;i<me.nextErrs.length;i++){
					me.nextErrs[i]();
				}
			}
		})
	}
};

//得到页面可见区域宽高
js.pageClientWH = function(){
	var d = document,b = d.body,de = d.documentElement,max = Math.max
	,w = max(b.clientWidth,de.clientWidth)
	,h = max(b.clientHeight,de.clientHeight);
	
	return {"width":w,"height":h};
};
//得到页面被卷去的top,left
js.pageScrollTL = function(){
	var d = document,b = d.body,de = d.documentElement,max = Math.max
	,top = max(b.scrollTop,de.scrollTop)
	,left = max(b.scrollLeft,de.scrollLeft);
	
	return {"top":top, "left":left};
};

//iframe自适应宽高
js.iframeAuto =  function(iframe){
	//alert(1);
	try{
		var d = iframe.contentWindow.document
			,bh = d.body.scrollHeight
			,dh = d.documentElement.scrollHeight
			,H = Math.max(bh,dh);
		iframe.height = H;
		iframe.width = Math.max(d.body.scrollWidth,d.documentElement.scrollWidth);
	}catch(ex){}
};

//----------简单拖动
js.easyDrag =  function(drag_o,handle_o){
	var x,y,m_x,m_y;
	handle_o.bind("mousedown",function(e){
		var e = e || window.event;
		m_x = e.clientX,m_y = e.clientY,x = parseInt(drag_o.css("left")),y = parseInt(drag_o.css("top"));
		jQuery(document).bind("mousemove",move);
		jQuery(document).bind("mouseup",stopMove);
	});
	var move = function(e){
		var e = e || window.event;
		window.getSelection ? window.getSelection().removeAllRanges() : document.selection.empty();
		drag_o.css({"left":Math.max(0,x + e.clientX-m_x),"top":Math.max(0,y+e.clientY-m_y)});
	};
	var stopMove = function(e){
		var e = e||window.event;
		jQuery(document).unbind("mousemove",move);
		jQuery(document).unbind("mouseup",stopMove);
	};
};


//字符串相关
js.trim = function(str){
	return str.replace(/(^\s+)|(\s+$)/g,"");
};

js.formatEmail = function(name, address){
	return name + ' <' + address + '>';
};
}(jQuery);
