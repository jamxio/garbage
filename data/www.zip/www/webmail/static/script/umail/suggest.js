/**
* multi-suggest
* design by bravf @ 2010.8.10
*/
var UMAIL = UMAIL || {};
UMAIL.widget = UMAIL.widget || {};

UMAIL.widget.suggest = function(input,serverUrl){
	this.input = input;
	this.serverUrl = serverUrl + "&query=";//&query=...
	this.timerDelay = 200;
	
	this.timer  = null;
	this.container = jQuery("<div class='suggest-container'/>").appendTo(jQuery("body"));
	this.selectedItem = null;
	this.values="";
	this.query="";

	this.init();
};
UMAIL.widget.suggest.prototype = {
	init : function(){
		this.setInputEvent();
		this.setContainerRegion();
		this.setContainerEvent();
	},
	setInputEvent : function(){
		var self = this;
		var input = self.input;
		
		input.attr('autocomplete', 'off');//关闭浏览器自带的提示
		input.bind("keydown",function(ev){
			var keyCode = ev.keyCode;
			switch(keyCode){
				case 8 : //BACKSPACE
					if(self.container.css("display")!="none"){//若当前正在查询中，则回格键触发查询
						self._search();	
					} 
					break;
				case 9 : //TAB
					self._hideContainer();
					break;
				case 13 : //ENTER
					if(self.container.css("display")=="none"){
						return false;	
					}
					self._setInputVal(self._decodeData(self.selectedItem.html()));
					return false;
					break;
				case 32 : //SPACE
					break;
				case 38 : //UP
				case 40 : //DOWN
					if(self.container.css("display")=="none"){
						break;	
					}
					var item=null;
					item = self.selectedItem.prev();
					keyCode==40 && (item = self.selectedItem.next());
					if(!!item.html()){
						self.selectedItem.removeClass("selected-result");
						item.addClass("selected-result");
						self.selectedItem = item;
					}
					break;
				default : //其他键
					self._search(keyCode);
					break;
			}
		});
		input.bind("blur",function(){
			self._hideContainer();
			self.query="";
		});
	},
	setContainerRegion : function(){
		var self = this;
		var	pos = self.input.offset();
		var	container = self.container;
		
		container.css({
			"top":pos.top+self.input.height()+1,// 默认向上偏差 1, 以覆盖掉 input 的下边框
			"left":pos.left
		});
		container.css({"width":self.input.width()});
	},
	setContainerEvent : function(){
		var self = this;
		var container = self.container;
		
		container.bind("mouseover",function(ev){
			var el = ev.target || ev.srcElement;
			if(el.tagName.toLowerCase()==="li"){
				if(!!self.selectedItem){
					self.selectedItem.removeClass("selected-result");
				}
				el = jQuery(el);
				el.addClass("selected-result");
				self.selectedItem = el;	
			}
		});
		container.bind("mousedown",function(ev){// 鼠标按下时，让输入框不会失去焦点
			var xinput = document.getElementById(self.input.attr("id"));
			// 1. for IE
			xinput.onbeforedeactivate = function() {
				window.event.returnValue = false;
				xinput.onbeforedeactivate = null;
			};
			// 2. for W3C		
			return false;
		});
		container.bind("mouseup",function(ev){
			var el = ev.target || ev.srcElement;
			if(el.tagName.toLowerCase()==="li"){
				self._setInputVal(self._decodeData(jQuery(el).html()));
                return false;
			}
		});
	},
	unique : function(){
		var self = this;
		self._setValues();
		var tempArr = self.uniqueItem(self.values.split(";"));//使不重复
	
		var tempStr = "";
		jQuery(tempArr).each(function(){
			var thatStr = this.toString();
			thatStr.length>0 && (tempStr += "" + thatStr + ";"); //加空格，使分开											
		});
		self.values = tempStr;
		self.input.val(self.values);
		return self;
	},
	uniqueItem : function(arr){
		var c = {},newArr = [];
		for(var i=0;i<arr.length;i++){
			var itm = arr[i].replace(/(^\s+)|(\s+$)/,"");
			!c[itm] && (c[itm]=true,newArr.push(itm));
		}
		return newArr;
	},
	_search : function(keyCode){
		var self = this;
		if(!!self.timer){
			window.clearInterval(self.timer);//按键缓冲
		}
		self.timer = window.setTimeout(function(){	
			if(186 == keyCode){//若为';',则重置已有值
				self._hideContainer();
				return false;
			}
			var query = self._getQuery();
			if(query==self.query){//若今次query和上次query相等，则不执行查询
				return false;	
			}
			self.query = query;
			if(query==""){//若query为空字符串,则不执行查询
				self.container.hide();
				return false;	
			}
			AjaxMsg.get_fn(self.serverUrl+self.query,function(datas){
				var container = self.container;
				container.html("");//清空上一次结果
				if(datas.length>0){//有数据时候重新填充并显示
					self._showContainer();	
					var itemList = jQuery("<ol/>");
					jQuery(datas).each(function(i){
						var li = jQuery("<li/>").html(self._codeData(this));
						if(i==0){//默认第一项为选中项
							self.selectedItem = li;
							self.selectedItem.addClass("selected-result");
						}
						itemList.append(li);						   
					});
					container.append(itemList);
				}else{
					self._hideContainer();	
				}
			});				   
		},
		self.timerDelay);
	},
	_setInputVal : function(addValue){
		this._setValues();
		this.input.val(this.values + "" + addValue + ";");
		this.unique();
		this.formatValues();
		
		this.query = "";
		this.container.hide();
	},
	_codeData : function(val){
		return val.toString().replace("<","&lt;").replace(">","&gt;");
	},
	_decodeData : function(val){
		return val.toString().replace("&lt;","<").replace("&gt;",">");
	},
	_getQuery　: function(){
		var self = this;
		var value = self.input.val()._trim();
		
		var lastIndex = value.lastIndexOf(";")+1;
		return value.substr(lastIndex);
	},
	_setValues : function(){
		var self = this;
		var value = self.input.val()._trim();
		self.values = "";
		var lastIndex = value.lastIndexOf(";");
		if(lastIndex!=-1){
			self.values = value.substring(0,lastIndex+1);
		}
	},
	formatValues : function(){
		var self = this;
		var arr = self.values.split(";");
		if(arr.length>0){
			self.values = arr.slice(0,-1).join("; ")+"; ";
			self.input.val(self.values);
		}
	},
	_hideContainer : function(){
		this.container.css("display")!="none" && this.container.hide();
	},
	_showContainer : function(){
		this.container.css("display")=="none" && this.container.show();
	}
};