/**
 * Created by eric on 2016/11/2.
 */
function miaovAddEvent(oEle, sEventName, fnHandler)
{
    if(oEle.attachEvent)
    {
        oEle.attachEvent('on'+sEventName, fnHandler);
    }
    else
    {
        oEle.addEventListener(sEventName, fnHandler, false);
    }
}


function startMove(obj, iTarget, fnCallBackEnd)
{
    if(obj.timer)
    {
        clearInterval(obj.timer);
    }
    obj.timer=setInterval
    (
        function ()
        {
            doMove(obj, iTarget, fnCallBackEnd);
        },30
    );
}

function doMove(obj, iTarget, fnCallBackEnd)
{
    var iSpeed=(iTarget-obj.offsetHeight)/8;

    if(obj.offsetHeight==iTarget)
    {
        clearInterval(obj.timer);
        obj.timer=null;
        if(fnCallBackEnd)
        {
            fnCallBackEnd();
        }
    }
    else
    {
        iSpeed=iSpeed>0?Math.ceil(iSpeed):Math.floor(iSpeed);
        obj.style.height=obj.offsetHeight+iSpeed+'px';

        ((window.navigator.userAgent.match(/MSIE 6/ig) && window.navigator.userAgent.match(/MSIE 6/ig).length==2)?repositionAbsolute:repositionFixed)()
    }
}

function repositionAbsolute()
{
    var oDiv=document.getElementById('miaov_float_layer');
    var left=document.body.scrollLeft||document.documentElement.scrollLeft;
    var top=document.body.scrollTop||document.documentElement.scrollTop;
    var width=document.documentElement.clientWidth;
    var height=document.documentElement.clientHeight;

    oDiv.style.left=left+width-oDiv.offsetWidth+'px';
    oDiv.style.top=top+height-oDiv.offsetHeight+'px';
}

function repositionFixed()
{
    var oDiv=document.getElementById('miaov_float_layer');
    var width=document.documentElement.clientWidth;
    var height=document.documentElement.clientHeight;

    oDiv.style.left=width-oDiv.offsetWidth+'px';
    oDiv.style.top=height-oDiv.offsetHeight+'px';
}
function minTanChuang()
{
    $("#btn_min").click();
}

function seereview() {
    var reviewWaitNum =document.getElementById('reviewWaitNum');
    reviewWaitNum.click();
    document.getElementById('btn_close').click();
}

function TanChuang() {
    var oDiv = document.getElementById('miaov_float_layer');
    var oBtnMin = document.getElementById('btn_min');
    var oBtnClose = document.getElementById('btn_close');
    var oDivContent = oDiv.getElementsByTagName('div')[0];
    oDiv.style.display="";
    var iMaxHeight = 0;

    var isIE6 = window.navigator.userAgent.match(/MSIE 6/ig) && !window.navigator.userAgent.match(/MSIE 7|8/ig);

    oDiv.style.display = 'block';
    iMaxHeight = oDivContent.offsetHeight;

    if (isIE6) {
        oDiv.style.position = 'absolute';
        repositionAbsolute();
        miaovAddEvent(window, 'scroll', repositionAbsolute);
        miaovAddEvent(window, 'resize', repositionAbsolute);
    }
    else {
        oDiv.style.position = 'fixed';
        repositionFixed();
        miaovAddEvent(window, 'resize', repositionFixed);
    }

    oBtnMin.timer = null;
    oBtnMin.isMax = true;
    oBtnMin.onclick = function() {
        startMove
        (
            oDivContent, (this.isMax = !this.isMax) ? iMaxHeight : 0,
            function() {
                oBtnMin.className = oBtnMin.className == 'min' ? 'max' : 'min';
            }
        );
    };

    oBtnClose.onclick = function() {
        oDiv.style.display = 'none';
        oDiv.innerHTML = "";
        $.cookie("isClose",'yes',{ expires:1/8640});  //测试关闭十秒后才能再次弹出
    };

};

var i=0;
var title = document.title;
var num=$.cookie("num");
var move_Interval ='';
if(num==NaN||num==''){
    num = 0;
}
$(function (){
    if($.cookie("isClose") != 'yes')
    {
        TanChuang();
        setTimeout("minTanChuang()",5000); //测试5秒自动关闭
    }
    update_review_count_tip(num);
    setTimeout("chang_title()",10000);
});
function update_review_count_tip(n) {
    if(n==''||n==NaN){
        n=0;
    }
    n = parseInt(n);
    if(n==0){
        $('#miaov_float_layer').hide();
        $.cookie("isClose",'yes');
        return false;
    }else if(n==NaN||n==undefined){
        return false;
    }

    else{
        $.cookie("isClose",'no');
        $('#miaov_float_layer').find('b').text('您有'+n+'封未审核邮件');
        $('#miaov_float_layer').find('#i_num').text('您有'+n+'封邮件需要审核，点击立即审核');
        $('#reviewWaitNum').html('('+n+')');
        $('#miaov_float_layer').show();
        return false;
    }
}

function scroll() {
    var new_title = document.title;
    var frist_char = new_title.charAt(0);
    var right_str = new_title.substring(1, new_title.length);
    document.title = right_str + frist_char;
}
function close_tips() {
    var close_menu = $('#btn_close');
    close_menu.attr('data',1);
    close_menu.click();
}

function chang_title() {
    $.get('/webmail/index.php?module=operate&action=ajax_unread_count',function (m) {
        if(m!=undefined&&m!=''){
            i= parseInt(m);
            num =i;
            if(i==0&&move_Interval!=''){
                move_Interval=window.clearInterval(move_Interval);
            }
            else if(num>0){
                document.title ='您有'+num+'封未读信件';
            }
            setTimeout(function () {
                setInterval("auto_update_tips()",38000);
            },25000);
        }
    })
}
function auto_update_tips() {
    $.get('/webmail/index.php?module=operate&action=ajax_unread_count',function (m) {
        if(m!=undefined&&m!=''){
            i = parseInt(m);
            if(i==0){
                num=0;
                move_Interval=window.clearInterval(move_Interval);
                move_Interval ='';
                document.title =title;
            }else if(num != i){
                if(move_Interval=='')
                    move_Interval = setInterval("scroll()",500);
                num =i;
                document.title ='您有新未读邮件！'+num+'封未读信件';
            }else{
                if(num>0){
                    document.title ='您有'+num+'封未读信件';
                }else{
                    document.title =title;
                }
            }
        }
    })
    $.get('/webmail/index.php?module=operate&action=ajax_review_count',function (m) {
        update_review_count_tip(m);
    })
}



