
//检测指定的值是否为无效或空值
function isInvalid(v) {
	if(v == undefined || v == '') {
		return true;
	}
	return false;
}

//检测指定的值是否为空
function isEmpty(v) {
	if(v == '') {
		return true;
	}
	return false;
}

//密码强度检测
function evaluatePassword(word) {
	if (word == "") {
		return 0;
	}
	else if (word.length < 8) {
		return 1;
	}
	else {
		return word.match(/[a-z](?![^a-z]*[a-z])|[A-Z](?![^A-Z]*[A-Z])|\d(?![^\d]*\d)|[^a-zA-Z\d](?![a-zA-Z\d]*[^a-zA-Z\d])/g).length;
	}
}

//密码复杂度检测
/*function checkPassword(string) {
	var check1 = /[a-z]+/i;
	var check2 = /[0-9]+/i;
	if(string.length < 8 || !check1.test(string) || !check2.test(string)) {
		return false;
	}
	return true;
}*/
function checkPassword(string) {
	var check1 = /[a-z]/;
	var check6 = /[A-Z]/;
	var check2 = /[0-9]+/i;
	var check3 = new RegExp('^[0-9a-zA-Z~!@#$%^&*()_+\\[\\];\\-\\=\\\'\\\\,./<>?:\\"\\|\\{\\}`]+$', 'i');//符号，数字，字母
	var check4 = new RegExp('.*(.)\\1{3,}.*', 'g');
	
	
	if(string.length < 8) {
		return false;
	}
	if(string.length > 20) {
		return false;
	}
	if(!check1.test(string) || !check6.test(string) || !check2.test(string)) {
		return false;
	}
	if(!check3.test(string)){
		return false;
	}
	if(check4.test(string)) {
		return false;
	}

	var check5 = new RegExp('\\d+|[a-zA-Z]+', 'g');
	var match = string.match(check5);
	
	var index;
	var str_arr = new Array();
	for( index in match ) {
		if(match[index] && match[index].length>=3) {
			str_arr.push(match[index]);
		}
	}

	var res = true;
	index = 0;
	for(index in str_arr) {
		var v = str_arr[index];
		var v_len = v.length;
		
		var delta_arr = new Array();
		var lastdelta = '';
		for(var i=0; i<v_len; i++) {
			if(i == 0 || !v[i]) {
				continue;
			}
			var delta = v[i].charCodeAt() - v[i-1].charCodeAt();
			if((delta == 1 || delta == -1 || delta == 0) && (delta == lastdelta || delta_arr.length == 0)) {
				delta_arr.push(v[i]);
				lastdelta = delta;
			}
			else
				delta_arr.length = 0;
		}


		if(delta_arr.length >= 2) {
			res = false;
			break;
		}

	}

	if(!res) {
		return false;
	}


	return true;
}

//检测字串格式
//调用方法：checkStringFormat(string, {type: 'custom', pattern: /^[a-zA-Z0-9_]{3,15}$/})
function checkStringFormat(string, param) {
	if(isInvalid(string)) {return false;}
	if(isInvalid(param.type)) {alert("参数错误！");return false;}
	if(!isInvalid(param.length) && (string.length > param.length)) {return false;}

	var type = param.type;
	switch(type) {
		case "custom":
			if(isInvalid(param.pattern)) {alert("参数错误！");return false;}
			pattern = param.pattern;
		break;
		case "userid":
			pattern = /^[a-zA-Z0-9_]{3,15}$/;
		break;
		case "alphanum":
			pattern = /^[a-zA-Z0-9_.]*$/;
		break;
		case "mailname":
			pattern = /^\w+([-+.]\w+)*$/;
		break;
		case "number":
			pattern = /^\d+(\.(\d)+)?$/;
		break;
		case "integer":
			pattern = /^[-\+]?\d+$/;
		break;
		case "chinese":
			pattern = /^[\u4e00-\u9fa5_a-zA-Z0-9_.]+$/;
		break;
		case "email":
			pattern = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
		break;
		case "domain":
			pattern = /^\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
		break;
		case "url":
			pattern = /^http:\/\/[A-Za-z0-9]+\.[A-Za-z0-9]+[\/=\?%\-&_~`@[\]\':+!]*([^<>\"\"])*$/;
		break;
		case "phones":
			pattern = /^[0-9-]{3,15}$/;
		break;
		case "mobile":
			pattern = /(^[1][3][0-9]{9}$)|(^0[1][3][0-9]{9}$)/;
		break;
		case "phone":
			pattern = /(^([0][1-9]{2,3}[-])?\d{3,8}(-\d{1,6})?$)|(^\([0][1-9]{2,3}\)\d{3,8}(\(\d{1,6}\))?$)|(^\d{3,8}$)/;
		break;
		case "date":
			var re_dt = /^(\d{4})\-(\d{1,2})\-(\d{1,2})$/;
			pattern = function (s_date) {
				if (!re_dt.test(s_date)) return false;
				if (RegExp.$3 > 31 || RegExp.$2 > 12) return false;
				var dt_test = new Date(RegExp.$1, Number(RegExp.$2-1), RegExp.$3);
				if (dt_test.getMonth() != Number(RegExp.$2-1)) return false;
				return true;
			}
		break;
		case "time":
			var re_tm = /^(\d{1,2})\:(\d{1,2})\:(\d{1,2})$/;
			pattern = function (s_time) {
				if (!re_tm.test(s_time)) return false;
				if (RegExp.$1 > 23 || RegExp.$2 > 59 || RegExp.$3 > 59) return false;
				return true;
			}
		break;
		case "ip":
			var re = /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/;
			pattern = function (s_ip) {
				if (!re.test(s_ip)) return false;
				if (RegExp.$1>255 || RegExp.$2>255 || RegExp.$3>255 || RegExp.$4>255) return false;
				return true;
			}
		break;
		case "mac":
			pattern = /^([0-9A-Fa-f]{2})(-[0-9A-Fa-f]{2}){5}|([0-9A-Fa-f]{2})(:[0-9A-Fa-f]{2}){5}/;
		break;
		case "port":
			var re = /^[-\+]?\d+$/;
			pattern = function(s_port) {
				if (!re.test(s_port)) return false;
				if (s_port > 65535) return false;
				return true;
			}
		break;
	}

	if(typeof(pattern) != "function") {
		if(!pattern.test(string)) return false;
		if(string.search(pattern) == -1) return false;
	}
	else if(!pattern(string)) {
		return false;
	}

	return true;
}

